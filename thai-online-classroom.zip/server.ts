import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { S3Client, GetObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { createClient } from "@supabase/supabase-js";
import dotenv from "dotenv";
import { Readable } from "stream";

dotenv.config();

function parseS3Url(url: string) {
  let bucket = process.env.AWS_S3_BUCKET || "";
  let key = url;
  let region = process.env.AWS_REGION || "us-east-1";

  if (url.startsWith("s3://")) {
    const withoutScheme = url.slice(5);
    const slashIdx = withoutScheme.indexOf("/");
    if (slashIdx !== -1) {
      bucket = withoutScheme.slice(0, slashIdx);
      key = withoutScheme.slice(slashIdx + 1);
    } else {
      bucket = withoutScheme;
      key = "";
    }
  } else if (url.includes(".amazonaws.com") || url.includes(".amazonaws.com.cn")) {
    try {
      const parsed = new URL(url);
      const host = parsed.hostname;

      // Extract region if present in the S3 URL (e.g. s3.ap-southeast-1.amazonaws.com or bucket.s3.ap-southeast-1.amazonaws.com)
      const regionMatch = host.match(/s3[-.]([a-z0-9-]+)\.amazonaws\.com/i);
      if (regionMatch && regionMatch[1] && regionMatch[1] !== "control") {
        region = regionMatch[1];
      }

      // 1. Virtual-hosted style: matches bucket-name.s3.Region.amazonaws.com or bucket-name.s3.amazonaws.com
      const virtualMatch = host.match(/^([a-z0-9.-]+)\.s3[-.]/i);
      if (virtualMatch) {
        bucket = virtualMatch[1];
        key = parsed.pathname.slice(1);
      }
      // 2. Path-style: matches s3.Region.amazonaws.com/bucket-name/... or s3.amazonaws.com/bucket-name/...
      else if (/^s3[-.]/i.test(host)) {
        const pathParts = parsed.pathname.split("/").filter(Boolean);
        if (pathParts.length > 0) {
          bucket = pathParts[0];
          key = pathParts.slice(1).join("/");
        }
      } else {
        // Fallback for custom formatted hosts
        key = parsed.pathname.slice(1);
      }
    } catch (e) {
      // Fallback
    }
  } else {
    // If it is just a plain key path
    if (key.startsWith("/")) {
      key = key.slice(1);
    }
  }

  return { 
    bucket, 
    key: decodeURIComponent(key), 
    region 
  };
}

function parseSupabaseUrl(url: string) {
  let bucket = "";
  let key = "";

  const trimmedUrl = url.trim();

  if (trimmedUrl.startsWith("supabase://")) {
    const withoutScheme = trimmedUrl.slice(11);
    const slashIdx = withoutScheme.indexOf("/");
    if (slashIdx !== -1) {
      bucket = withoutScheme.slice(0, slashIdx);
      key = withoutScheme.slice(slashIdx + 1);
    } else {
      bucket = withoutScheme;
      key = "";
    }
  } else if (trimmedUrl.includes(".supabase.co")) {
    try {
      const urlToParse = trimmedUrl.startsWith("http") ? trimmedUrl : `https://${trimmedUrl}`;
      const parsed = new URL(urlToParse);
      const pathname = parsed.pathname;
      const parts = pathname.split("/").filter(Boolean);
      
      const objectIdx = parts.indexOf("object");
      if (objectIdx !== -1 && parts.length > objectIdx + 1) {
        // The parts starting after "object"
        const remainingParts = parts.slice(objectIdx + 1);
        
        // Check if the first part is a known category like public, authenticated, sign, or private
        const categories = ["public", "authenticated", "sign", "private"];
        if (categories.includes(remainingParts[0].toLowerCase())) {
          if (remainingParts.length > 2) {
            bucket = remainingParts[1];
            key = remainingParts.slice(2).join("/");
          } else if (remainingParts.length === 2) {
            bucket = remainingParts[1];
            key = "";
          }
        } else {
          // It doesn't have a category (e.g. storage/v1/object/bucket/key)
          bucket = remainingParts[0];
          key = remainingParts.slice(1).join("/");
        }
      } else {
         // Maybe it's just the url without object, or an S3 compatible url like /storage/v1/s3/...
         // Try to find /storage/v1/s3 or similar patterns
         const s3Idx = parts.indexOf("s3");
         if (s3Idx !== -1 && parts[s3Idx - 1] === "v1" && parts.length > s3Idx + 1) {
            bucket = parts[s3Idx + 1];
            key = parts.slice(s3Idx + 2).join("/");
         } else {
           // Provide fallback by discarding everything before the real bucket if we don't know the format?
           // No, maybe we should just fallback to the general check.
           throw new Error("Could not parse supabase.co url natively");
         }
      }
    } catch (e) {
      // Fallback
      let cleanUrl = trimmedUrl;
      const hostIdx = cleanUrl.indexOf(".supabase.co");
      if (hostIdx !== -1) {
        const slashAfterHost = cleanUrl.indexOf("/", hostIdx);
        if (slashAfterHost !== -1) {
          cleanUrl = cleanUrl.slice(slashAfterHost + 1);
        } else {
          cleanUrl = "";
        }
      }
      if (cleanUrl.startsWith("storage/v1/object/public/")) {
        cleanUrl = cleanUrl.slice("storage/v1/object/public/".length);
      } else if (cleanUrl.startsWith("storage/v1/object/")) {
        cleanUrl = cleanUrl.slice("storage/v1/object/".length);
      }
      
      if (cleanUrl.includes("?")) cleanUrl = cleanUrl.split("?")[0];
      
      const slashIdx = cleanUrl.indexOf("/");
      if (slashIdx !== -1) {
        bucket = cleanUrl.slice(0, slashIdx);
        key = cleanUrl.slice(slashIdx + 1);
      } else {
        bucket = cleanUrl;
        key = "";
      }
    }
  } else {
    // Plain key fallback - we extract first word as bucket name if it's "bucket/path"
    let cleanUrl = trimmedUrl;
    if (cleanUrl.startsWith("/")) {
      cleanUrl = cleanUrl.slice(1);
    }
    // Remove query parameters if present in the plain URL fallback
    if (cleanUrl.includes("?")) {
      cleanUrl = cleanUrl.split("?")[0];
    }
    const slashIdx = cleanUrl.indexOf("/");
    if (slashIdx !== -1) {
      bucket = cleanUrl.slice(0, slashIdx);
      key = cleanUrl.slice(slashIdx + 1);
    } else {
      bucket = "videos"; // default fallback bucket name
      key = cleanUrl;
    }
  }

  // Sanitize key and bucket to prevent Supabase's 'Invalid path specified in request URL' error
  let decodedKey = decodeURIComponent(key).trim();
  // Strip leading/trailing slashes, and combine multiple consecutive slashes (e.g. key//file -> key/file)
  decodedKey = decodedKey.replace(/^\/+|\/+$/g, "").replace(/\/+/g, "/");

  const cleanBucket = bucket.trim().replace(/^\/+|\/+$/g, "");

  console.log(`[Supabase URL Parser Inputs] url="${url}" -> extracted bucket="${cleanBucket}" key="${decodedKey}"`);

  return { 
    bucket: cleanBucket, 
    key: decodedKey 
  };
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Unified Cloud Secrets Diagnostic details for Instructors
  app.get("/api/videos/debug-s3", (req, res) => {
    const awsKeyId = process.env.AWS_ACCESS_KEY_ID;
    const awsSecret = process.env.AWS_SECRET_ACCESS_KEY;
    const rawSupabaseUrl = process.env.SUPABASE_URL || "";
    const supabaseUrlMatch = rawSupabaseUrl.match(/^(https?:\/\/[^/]+)/);
    const sanitizedSupabaseUrl = supabaseUrlMatch ? supabaseUrlMatch[1] : rawSupabaseUrl;
    const hasPathWarning = rawSupabaseUrl !== sanitizedSupabaseUrl;
    const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

    res.json({
      AWS_ACCESS_KEY_ID_STATUS: awsKeyId ? `Configured (${awsKeyId.substring(0, 4)}...${awsKeyId.substring(awsKeyId.length - 4)} - length: ${awsKeyId.length} chars)` : "Missing/Not configured in Environment",
      AWS_SECRET_ACCESS_KEY_STATUS: awsSecret ? `Configured (length: ${awsSecret.length} chars)` : "Missing/Not configured in Environment",
      AWS_REGION: process.env.AWS_REGION || "us-east-1",
      AWS_S3_BUCKET: process.env.AWS_S3_BUCKET || "Missing/Not configured in Environment",
      SUPABASE_URL_STATUS: rawSupabaseUrl ? `Configured (${sanitizedSupabaseUrl})${hasPathWarning ? ' (⚠️ Removed invalid trailing path from URL)' : ''}` : "Missing/Not configured in Environment",
      SUPABASE_KEY_STATUS: supabaseKey ? `Configured (length: ${supabaseKey.length} chars)` : "Missing/Not configured in Environment"
    });
  });

  // Anti-leech video proxy route
  app.get("/api/videos/stream-chunk", async (req, res) => {
    const token = req.query.token as string;
    if (!token) return res.status(403).json({ error: "No token provided" });

    // Optional Anti-leech protection: Require referer
    const referer = req.headers.referer || req.headers.origin;
    // Allow basic requests but block explicit cross-origin or no-referer curl downloads unless testing locally
    if (process.env.NODE_ENV === "production" && !referer?.includes(req.headers.host || "")) {
       // Only enable strict referer checking if needed. For now, comment out to prevent breaking valid cases.
       // return res.status(403).send("Forbidden");
    }

    try {
      const actualUrl = Buffer.from(token, "base64").toString("utf-8");
      if (!actualUrl.startsWith("http")) return res.status(400).send("Invalid url");

      const fetchHeaders: any = {};
      if (req.headers.range) fetchHeaders["Range"] = req.headers.range;

      const fetchResponse = await fetch(actualUrl, { headers: fetchHeaders });
      res.status(fetchResponse.status);
      
      fetchResponse.headers.forEach((val, key) => {
        // Exclude headers that express handles or that could cause issues
        const lowerKey = key.toLowerCase();
        if (!['content-encoding', 'connection', 'keep-alive', 'transfer-encoding'].includes(lowerKey)) {
          res.setHeader(key, val);
        }
      });

      if (fetchResponse.body) {
        Readable.fromWeb(fetchResponse.body as any).pipe(res);
      } else {
        res.end();
      }
    } catch (err) {
      console.error("Proxy error:", err);
      if (!res.headersSent) res.status(500).send("Proxy error");
    }
  });

  // API Route to presign AWS S3 or Supabase Storage URLs securely
  app.post("/api/videos/sec-presign", async (req, res) => {
    const { videoUrl } = req.body;

    if (!videoUrl) {
      return res.status(400).json({ error: "No videoUrl provided" });
    }

    const isSupabase = videoUrl.startsWith("supabase://") || videoUrl.includes(".supabase.co");
    const isS3 = videoUrl.startsWith("s3://") || videoUrl.includes(".amazonaws.com");

    // Dynamic routing depending on URL prefix/host or fallbacks based on loaded keys
    const useSupabase = isSupabase || (!isS3 && process.env.SUPABASE_URL && process.env.SUPABASE_SERVICE_ROLE_KEY);

    if (useSupabase) {
      const rawSupabaseUrl = process.env.SUPABASE_URL || "";
      const supabaseUrlMatch = rawSupabaseUrl.match(/^(https?:\/\/[^/]+)/);
      const supabaseUrl = supabaseUrlMatch ? supabaseUrlMatch[1] : rawSupabaseUrl;
      const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || "";

      if (!supabaseUrl || !supabaseKey) {
        return res.status(400).json({
          error: "Supabase is not configured",
          needConfig: true,
          message: "กรุณากำหนดค่า SUPABASE_URL และ SUPABASE_SERVICE_ROLE_KEY ในหน้าตั้งค่า (Secrets) เพื่อเปิดใช้งานการดึงวิดีโอจาก Supabase Storage อย่างปลอดภัย"
        });
      }

      try {
        console.log("Processing Supabase presign, url=", videoUrl);
        if (videoUrl.includes("/object/public/")) {
            console.log("It's a public url, skipping sign...");
            const proxyUrl = `/api/videos/stream-chunk?token=${Buffer.from(videoUrl).toString("base64")}`;
            return res.json({
                success: true,
                provider: "supabase",
                signedUrl: proxyUrl,
                bucket: "public",
                key: "public"
            });
        }

        const { bucket, key } = parseSupabaseUrl(videoUrl);

        if (!bucket || !key) {
          return res.status(400).json({
            error: "Supabase bucket or key could not be identified",
            message: "ไม่สามารถแยกแยะ Bucket หรือ Key ของ Supabase ได้ กรุณาตรวจสอบรูปแบบคีย์หรือรูปแบบลิงก์"
          });
        }

        const supabase = createClient(supabaseUrl, supabaseKey);
        
        // Generate a private signed URL valid for 1 hour (3600 seconds)
        const { data, error } = await supabase.storage
          .from(bucket)
          .createSignedUrl(key, 3600);

        if (error || !data?.signedUrl) {
          throw new Error(error?.message || "Could not retrieve signed URL from Supabase Storage");
        }

        const proxyUrl = `/api/videos/stream-chunk?token=${Buffer.from(data.signedUrl).toString("base64")}`;

        return res.json({
          success: true,
          provider: "supabase",
          signedUrl: proxyUrl,
          bucket,
          key
        });
      } catch (err: any) {
        console.error("Supabase Storage URL signing failed:", err);
        return res.status(500).json({
          error: "Super Modified Error String 123",
          message: err.message
        });
      }
    } else {
      // AWS S3 Path (Explicitly requested or as ultimate S3 fallback)
      const accessKeyId = process.env.AWS_ACCESS_KEY_ID;
      const secretAccessKey = process.env.AWS_SECRET_ACCESS_KEY;
      const region = process.env.AWS_REGION || "us-east-1";

      if (!accessKeyId || !secretAccessKey) {
        return res.status(400).json({
          error: "Cloud Storage is not configured",
          needConfig: true,
          message: "กรุณากำหนดข้อมูล Secrets ในแถบการตั้งค่า เช่น AWS S3 (AWS_ACCESS_KEY_ID) หรือ Supabase (SUPABASE_URL) เพื่อใช้ระบบจัดเก็บวิดีโอส่วนตัว"
        });
      }

      try {
        const { bucket, key, region: urlRegion } = parseS3Url(videoUrl);

        if (!bucket) {
          return res.status(400).json({
            error: "S3 Bucket name could not be identified",
            message: "ไม่สามารถระบุชื่อ S3 Bucket ได้ กรุณาตรวจสอบลิงก์วิดีโอหรือกำหนดค่า AWS_S3_BUCKET"
          });
        }

        const finalRegion = urlRegion || region;

        const s3Client = new S3Client({
          region: finalRegion,
          credentials: {
            accessKeyId,
            secretAccessKey
          }
        });

        const command = new GetObjectCommand({
          Bucket: bucket,
          Key: key
        });

        const signedUrl = await getSignedUrl(s3Client, command, { expiresIn: 3600 });
        const proxyUrl = `/api/videos/stream-chunk?token=${Buffer.from(signedUrl).toString("base64")}`;

        return res.json({
          success: true,
          provider: "s3",
          signedUrl: proxyUrl,
          bucket,
          key
        });
      } catch (err: any) {
        console.error("S3 Presign generation failed:", err);
        return res.status(500).json({
          error: "Failed to generate presigned URL",
          message: err.message
        });
      }
    }
  });

  // Serve Vite or Static files depending on process.env.NODE_ENV
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
