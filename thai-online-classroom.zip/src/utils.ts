/**
 * Utility to extract YouTube video ID from various link formats.
 */
export function getYouTubeId(url: string): string | null {
  if (!url) return null;
  // Handle shorts specifically
  if (url.includes('/shorts/')) {
    const parts = url.split('/shorts/');
    const idParts = parts[1].split('?');
    return idParts[0];
  }
  const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
  const match = url.match(regExp);
  return (match && match[2].length === 11) ? match[2] : null;
}

export function getDriveId(url: string): string | null {
  if (!url) return null;
  const match = url.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
  if (match && match[1]) {
    return match[1];
  }
  return null;
}

/**
 * Capitalizes or structures dates in Thai-friendly format.
 */
export function formatThaiDate(timestamp: any): string {
  if (!timestamp) return 'เมื่อสักครู่';
  try {
    const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
    return date.toLocaleDateString('th-TH', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }) + ' น.';
  } catch (e) {
    return 'ไม่ระบุเวลา';
  }
}

/**
 * Standard Sky/Blue gradients & banners
 */
export const BANNER_COLORS = [
  'from-sky-400 to-blue-500', 
  'from-blue-400 to-indigo-500', 
  'from-cyan-400 to-sky-500',
  'from-teal-400 to-blue-400',
  'from-indigo-400 to-sky-400'
];
