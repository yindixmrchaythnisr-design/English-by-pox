import React, { useState, useEffect } from 'react';
import { Course } from '../types';
import { BookOpen, User, Calendar, GraduationCap, ChevronRight } from 'lucide-react';
import { formatThaiDate } from '../utils';
import { db, auth } from '../firebase';
import { collection, query, where, getDocs } from 'firebase/firestore';

interface CourseCardProps {
  course: Course;
  isEnrolled: boolean;
  isCreator: boolean;
  onView: () => void;
  onEnroll: () => void;
  isProcessing: boolean;
}

export default function CourseCard({
  course,
  isEnrolled,
  isCreator,
  onView,
  onEnroll,
  isProcessing
}: CourseCardProps) {
  const [progressPercentage, setProgressPercentage] = useState<number>(0);
  const [timeLeftText, setTimeLeftText] = useState<string>('');
  const [lessonsCount, setLessonsCount] = useState<number>(0);

  useEffect(() => {
    let active = true;
    const fetchLessonsAndCalc = async () => {
      try {
        const q = query(collection(db, 'lessons'), where('courseId', '==', course.id));
        const snap = await getDocs(q);
        if (!active) return;
        
        const count = snap.size;
        setLessonsCount(count);
        
        const lessonsList = snap.docs.map(d => ({ id: d.id }));
        
        const updateProgressView = () => {
          const userId = auth.currentUser?.uid;
          if (!userId) {
            setProgressPercentage(0);
            setTimeLeftText('');
            return;
          }
          
          const key = `course_progress_${userId}_${course.id}`;
          let progressDict: Record<string, any> = {};
          try {
            const saved = localStorage.getItem(key);
            if (saved) {
              progressDict = JSON.parse(saved);
            }
          } catch (e) {
            console.error(e);
          }
          
          if (count === 0) {
            setProgressPercentage(0);
            setTimeLeftText('ไม่มีวิดีโอบทเรียน');
            return;
          }
          
          let totalPercentage = 0;
          let totalTimeRemainingSeconds = 0;
          
          lessonsList.forEach(les => {
            const recorded = progressDict[les.id];
            if (recorded) {
              totalPercentage += recorded.percentage || 0;
              totalTimeRemainingSeconds += recorded.timeLeftSeconds ?? 0;
            } else {
              totalPercentage += 0;
              // Default guess - 12 mins per unstarted lesson video (720 seconds)
              totalTimeRemainingSeconds += 720;
            }
          });
          
          const avgPercentage = Math.round(totalPercentage / count);
          setProgressPercentage(avgPercentage);
          
          if (avgPercentage >= 100) {
            setTimeLeftText('Finished');
          } else {
            const minutesRemaining = Math.ceil(totalTimeRemainingSeconds / 60);
            if (minutesRemaining >= 60) {
              const hours = Math.floor(minutesRemaining / 60);
              const mins = minutesRemaining % 60;
              setTimeLeftText(`เหลืออีกประมาณ ${hours} ชม. ${mins} นาที`);
            } else {
              setTimeLeftText(`เหลืออีกประมาณ ${minutesRemaining} นาที`);
            }
          }
        };
        
        updateProgressView();
        
        // Listen to storage events to auto-refresh progress
        const onStorageChange = () => {
          updateProgressView();
        };
        window.addEventListener('storage', onStorageChange);
        return () => {
          window.removeEventListener('storage', onStorageChange);
        };
      } catch (err) {
        console.error('Error fetching lessons for card:', err);
      }
    };
    
    fetchLessonsAndCalc();
    
    return () => {
      active = false;
    };
  }, [course.id, auth.currentUser?.uid]);

  // Extract banner color class or default to sky gradient
  const bannerBg = course.bannerColor || 'from-sky-500 to-blue-600';

  // Dynamic Google-style initials avatar
  const avatarUrl = `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(course.creatorName)}&backgroundColor=0284c7,3b82f6,0ea5e9,10b981,6366f1`;

  return (
    <div
      className="bg-gradient-to-r from-[#F6EFCD] via-white to-[#F6EFCD] rounded-xl border border-gray-200 shadow-xs overflow-hidden hover:shadow-md transition-all duration-200 flex flex-col h-[340px] justify-between relative group"
      id={`course-card-${course.id}`}
    >
      {/* Decorative colored header (Google Classroom banner format) */}
      <div className={`h-32 bg-gradient-to-tr ${bannerBg} p-4 flex flex-col justify-between relative shrink-0`}>
        <div className="absolute inset-0 bg-black/5 mix-blend-overlay"></div>
        
        {/* Badges & Course Details inside the Banner */}
        <div className="flex justify-between items-start z-10 w-full">
          <span className="bg-white/20 backdrop-blur-md text-white text-[10px] font-bold px-2 py-0.5 rounded-md">
            คอร์ส ID: {course.id.substring(7, 12)}
          </span>

          {isCreator ? (
            <span className="bg-emerald-500 text-white text-[10px] font-bold px-2.5 py-0.5 rounded-full shadow-xs">
              ฉันเป็นผู้สอน
            </span>
          ) : isEnrolled ? (
            <span className="bg-blue-600 border border-blue-400 text-white text-[10px] font-bold px-2.5 py-0.5 rounded-full shadow-xs">
              ลงทะเบียนแล้ว
            </span>
          ) : null}
        </div>

        {/* Course name and Instructor nested directly in the banner */}
        <div className="z-10 text-left">
          <h3 
            onClick={(isEnrolled || isCreator) ? onView : undefined}
            className={`font-sans font-medium text-white text-lg tracking-tight line-clamp-1 ${(isEnrolled || isCreator) ? 'cursor-pointer hover:underline' : ''}`}
            title={course.title}
          >
            {course.title}
          </h3>
          <p className="text-xs text-white/95 font-sans mt-0.5 line-clamp-1">
            ผู้สอน: {course.creatorName}
          </p>
        </div>
      </div>

      {/* Floating Teacher Initial Avatar overlapping the banner margin */}
      <img
        src={avatarUrl}
        alt={course.creatorName}
        referrerPolicy="no-referrer"
        className="h-14 w-14 rounded-full border-2 border-white shadow-sm absolute right-4 top-20 z-20 object-cover bg-white"
        title={`โปรไฟล์ผู้เขียน: ${course.creatorName}`}
      />

      {/* Course Body (White card content) */}
      <div className="p-4 flex-1 flex flex-col justify-between relative">
        {/* Description & metadata */}
        <div className="text-left mt-1">
          <span className="text-[10px] text-zinc-400/90 font-mono block mb-1">
            สร้างเมื่อ: {formatThaiDate(course.createdAt)}
          </span>
          <p className="text-xs text-zinc-500 line-clamp-3 leading-relaxed font-sans pr-4">
            {course.description || 'ไม่มีรายละเอียดวิชาเรียนที่โพสต์ไว้เบื้องต้น สามารถเข้าศึกษาเนื้อหาเพิ่มเติมได้โดยการกดเข้าร่วมห้องเรียน'}
          </p>
        </div>

        {/* Elegant Green Track Progress Bar & Time left to finish video */}
        {(isEnrolled || isCreator) && (
          <div className="mt-2 mb-1 space-y-1.5 text-left">
            <div className="flex justify-between items-center text-[10px] font-sans">
              <span className="font-semibold text-emerald-700 flex items-center">
                <span className={`w-1.5 h-1.5 bg-emerald-500 rounded-full ${lessonsCount > 0 && progressPercentage > 0 && progressPercentage < 100 ? 'animate-pulse' : ''} mr-1`}></span>
                <span>เรียนแล้ว {lessonsCount > 0 ? `${progressPercentage}%` : '0%'}</span>
              </span>
              <span className="text-zinc-500 font-mono text-[9px] bg-zinc-100 px-1.5 py-0.5 rounded-sm">
                {lessonsCount > 0 ? timeLeftText : 'ไม่มีวิดีโอบทเรียน'}
              </span>
            </div>
            {/* Bright Green completed bar over a soft minty green background track */}
            <div className="w-full h-1.5 bg-emerald-100/60 rounded-full overflow-hidden">
              <div 
                className="h-full bg-emerald-500 rounded-full transition-all duration-500 ease-out" 
                style={{ width: `${lessonsCount > 0 ? progressPercentage : 0}%` }}
              />
            </div>
          </div>
        )}

        {/* Google Classroom styled bottom-border action section */}
        <div className="pt-3 border-t border-gray-100 flex items-center justify-between mt-2 shrink-0">
          <span className="text-[10px] text-zinc-400 font-sans flex items-center space-x-1">
            <BookOpen className="h-3 w-3 shrink-0 text-blue-500" />
            <span>ห้องเรียนสารบัญความรู้</span>
          </span>

          <div className="w-1/2">
            {isEnrolled || isCreator ? (
              <button
                onClick={onView}
                className="w-full flex items-center justify-center space-x-1 bg-gray-50 hover:bg-gray-100 text-zinc-700 hover:text-black py-1.5 px-3 rounded-lg text-xs font-semibold border border-gray-200 transition-all duration-200"
                id={`btn-view-${course.id}`}
              >
                <span>เข้าชั้นเรียน</span>
                <ChevronRight className="h-3.5 w-3.5" />
              </button>
            ) : (
              <button
                onClick={onEnroll}
                disabled={isProcessing}
                className="w-full flex items-center justify-center space-x-1 bg-blue-600 hover:bg-blue-700 text-white py-1.5 px-3 rounded-lg text-xs font-semibold shadow-2xs transition-colors duration-250 disabled:opacity-50"
                id={`btn-enroll-${course.id}`}
              >
                <GraduationCap className="h-3.5 w-3.5" />
                <span>{isProcessing ? 'กำลังเข้า...' : 'เข้าร่วมชั้นเรียน'}</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
