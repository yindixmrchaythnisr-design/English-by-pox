import React, { useState, useEffect, useRef } from 'react';
import { 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Maximize2, 
  Minimize2, 
  Loader2,
  Shield,
  Lock
} from 'lucide-react';
import { UserProfile } from '../types';

declare global {
  interface Window {
    YT: any;
    onYouTubeIframeAPIReady: (() => void) | undefined;
  }
}

interface SecureVideoPlayerProps {
  videoUrl?: string;
  youtubeId?: string;
  currentUser: UserProfile;
  title: string;
  userIp?: string;
  courseId?: string;
  lessonId?: string;
}

// Global script cache to prevent double-loading YouTube Iframe Player API
let ytApiPromise: Promise<any> | null = null;
function loadYouTubeApi(): Promise<any> {
  if (window.YT && window.YT.Player) {
    return Promise.resolve(window.YT);
  }
  if (ytApiPromise) {
    return ytApiPromise;
  }
  ytApiPromise = new Promise((resolve, reject) => {
    const existingScript = document.querySelector('script[src*="youtube.com/iframe_api"]');
    if (!existingScript) {
      const tag = document.createElement('script');
      tag.src = 'https://www.youtube.com/iframe_api';
      tag.onerror = () => reject(new Error('Failed to load YouTube API'));
      const firstScriptTag = document.getElementsByTagName('script')[0];
      if (firstScriptTag && firstScriptTag.parentNode) {
        firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
      } else {
        document.head.appendChild(tag);
      }
    }
    
    const previousReady = window.onYouTubeIframeAPIReady;
    window.onYouTubeIframeAPIReady = () => {
      if (previousReady) {
        try {
          previousReady();
        } catch (e) {
          console.error(e);
        }
      }
      resolve(window.YT);
    };

    // If already initialized but we missed the event
    if (window.YT && window.YT.Player) {
      resolve(window.YT);
    }
  });
  return ytApiPromise;
}

export default function SecureVideoPlayer({ videoUrl, youtubeId, currentUser, title, userIp, courseId, lessonId }: SecureVideoPlayerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const ytPlayerRef = useRef<any>(null);

  const courseIdRef = useRef(courseId);
  const lessonIdRef = useRef(lessonId);
  const userIdRef = useRef(currentUser?.uid);

  useEffect(() => {
    courseIdRef.current = courseId;
    lessonIdRef.current = lessonId;
    userIdRef.current = currentUser?.uid;
  }, [courseId, lessonId, currentUser]);

  const saveProgress = (currentTimeVal: number, durationVal: number) => {
    const cId = courseIdRef.current;
    const lId = lessonIdRef.current;
    const uId = userIdRef.current;
    if (!uId || !cId || !lId || !durationVal || durationVal <= 0) return;
    
    const key = `course_progress_${uId}_${cId}`;
    let progressDict: Record<string, any> = {};
    try {
      const saved = localStorage.getItem(key);
      if (saved) {
        progressDict = JSON.parse(saved);
      }
    } catch (e) {
      console.error(e);
    }
    
    const percentage = Math.min(100, Math.round((currentTimeVal / durationVal) * 100));
    const timeLeftSeconds = Math.max(0, Math.round(durationVal - currentTimeVal));
    
    progressDict[lId] = {
      percentage,
      timeLeftSeconds,
      duration: durationVal,
      currentTime: currentTimeVal,
      timestamp: Date.now()
    };
    
    localStorage.setItem(key, JSON.stringify(progressDict));
    window.dispatchEvent(new Event('storage'));
  };

  // Video State
  const [isPlaying, setIsPlaying] = useState(false);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [volume, setVolume] = useState(80);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [showControls, setShowControls] = useState(true);
  const [videoError, setVideoError] = useState<string | null>(null);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [bypassShield, setBypassShield] = useState(false);

  // AWS S3 or Supabase Storage video resolver states
  const [resolvedUrl, setResolvedUrl] = useState<string | undefined>(undefined);
  const [isPresigning, setIsPresigning] = useState(false);
  const [s3Error, setS3Error] = useState<string | null>(null);

  const isSecureCloudUrl = (url?: string): boolean => {
    if (!url) return false;
    return (
      url.startsWith('s3://') ||
      url.startsWith('supabase://') ||
      url.includes('.amazonaws.com') ||
      url.includes('.supabase.co') ||
      (!url.startsWith('http://') && !url.startsWith('https://') && !url.startsWith('/') && !url.startsWith('blob:'))
    );
  };

  useEffect(() => {
    if (!videoUrl) {
      setResolvedUrl(undefined);
      return;
    }

    let objectUrl: string | null = null;

    // New Strategy: Convert Public Cloud/Drive Video URLs to local memory blobs to prevent deep-linking/downloads
    if (videoUrl.includes('/object/public/') || (!videoUrl.includes('.amazonaws.com') && !videoUrl.includes('supabase') && videoUrl.startsWith('http'))) {
      setIsPresigning(true);
      setS3Error(null);
      setVideoError(null);
      setIsLoading(true);

      fetch(videoUrl)
        .then((res) => {
           if (!res.ok) throw new Error("Network response was not ok");
           return res.blob();
        })
        .then((blob) => {
          objectUrl = URL.createObjectURL(blob);
          setResolvedUrl(objectUrl);
          setIsLoading(false);
        })
        .catch((err) => {
          console.error("Failed to secure feed as blob, falling back to direct URL:", err);
          setResolvedUrl(videoUrl); 
          setIsLoading(false);
        })
        .finally(() => {
          setIsPresigning(false);
        });
      
      return () => {
        if (objectUrl) URL.revokeObjectURL(objectUrl);
      };
    }

    if (isSecureCloudUrl(videoUrl)) {
      setIsPresigning(true);
      setS3Error(null);
      setVideoError(null);
      setIsLoading(true);

      fetch('/api/videos/sec-presign', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ videoUrl }),
      })
        .then((res) => {
          if (!res.ok) {
            return res.json().then((err) => { throw err; });
          }
          return res.json();
        })
        .then((data) => {
          if (data.success && data.signedUrl) {
            setResolvedUrl(data.signedUrl);
          } else {
            const msg = data.message || 'Failed to generate signed URL';
            setS3Error(msg);
            setVideoError(msg);
            setIsLoading(false);
          }
        })
        .catch((err: any) => {
          console.error('Error signing video URL:', err);
          const msg = err.message || 'กรุณากำหนดค่า AWS S3 หรือ Supabase ในระบบ (Secrets) หลังบ้านเพื่อดูวิดีโอส่วนตัวอย่างปลอดภัย';
          setS3Error(msg);
          setVideoError(msg);
          setIsLoading(false);
        })
        .finally(() => {
          setIsPresigning(false);
        });
    } else {
      setResolvedUrl(videoUrl);
      setS3Error(null);
    }
  }, [videoUrl]);

  // Hook to make sure playbackSpeed is consistently applied to HTML5 video element when speed or source changes
  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.playbackRate = playbackSpeed;
    }
  }, [playbackSpeed, resolvedUrl]);

  // Floating Watermark position (Moves slowly to prevent screen capture crop-out)
  const [watermarkPos, setWatermarkPos] = useState({ x: 30, y: 20 });

  useEffect(() => {
    // Slower move to prevent cropping out
    const interval = setInterval(() => {
      const randomX = Math.floor(Math.random() * 60) + 10; // 10% to 70% range
      const randomY = Math.floor(Math.random() * 60) + 10; // 10% to 70% range
      setWatermarkPos({ x: randomX, y: randomY });
    }, 4500);
    return () => clearInterval(interval);
  }, []);

  // Controls Visibility Timer
  useEffect(() => {
    if (!isPlaying) {
      setShowControls(true);
      return;
    }
    
    const timer = setTimeout(() => {
      setShowControls(false);
    }, 3000);

    return () => clearTimeout(timer);
  }, [isPlaying, currentTime]);

  // Fullscreen tracking
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, []);

  // Sync state for HTML5 native video
  useEffect(() => {
    const videoObj = videoRef.current;
    if (!videoObj) return;

    const handlePlay = () => setIsPlaying(true);
    const handlePause = () => setIsPlaying(false);
    const handleDuration = () => {
      const dur = videoObj.duration || 0;
      setDuration(dur);
      if (dur > 0) {
        saveProgress(videoObj.currentTime || 0, dur);
      }
    };
    const handleLoading = () => setIsLoading(true);
    const handleLoaded = () => setIsLoading(false);
    const handleError = () => {
      console.error('Video error:', videoObj.error);
      setVideoError('ไม่สามารถโหลดหรือเล่นวิดีโอนี้ได้ (รูปแบบไม่รองรับหรือลิงก์เสีย)');
      setIsLoading(false);
    };
    
    const handleTimeUpdate = () => {
      setCurrentTime(videoObj.currentTime);
      if (videoObj.duration) {
        saveProgress(videoObj.currentTime, videoObj.duration);
      }
    };

    videoObj.addEventListener('play', handlePlay);
    videoObj.addEventListener('pause', handlePause);
    videoObj.addEventListener('durationchange', handleDuration);
    videoObj.addEventListener('timeupdate', handleTimeUpdate);
    videoObj.addEventListener('waiting', handleLoading);
    videoObj.addEventListener('playing', handleLoaded);
    videoObj.addEventListener('loadeddata', handleLoaded);
    videoObj.addEventListener('error', handleError);

    // Initial values
    if (videoObj.readyState >= 1) {
      const dur = videoObj.duration || 0;
      setDuration(dur);
      setIsLoading(false);
      if (dur > 0) {
        saveProgress(videoObj.currentTime || 0, dur);
      }
    } else if (videoObj.error) {
      setIsLoading(false);
    }

    return () => {
      videoObj.removeEventListener('play', handlePlay);
      videoObj.removeEventListener('pause', handlePause);
      videoObj.removeEventListener('durationchange', handleDuration);
      videoObj.removeEventListener('timeupdate', handleTimeUpdate);
      videoObj.removeEventListener('waiting', handleLoading);
      videoObj.removeEventListener('playing', handleLoaded);
      videoObj.removeEventListener('loadeddata', handleLoaded);
      videoObj.removeEventListener('error', handleError);
    };
  }, [resolvedUrl]);

  // Sync state for YouTube Iframe Player
  useEffect(() => {
    if (!youtubeId) return;
    
    let activePlayer: any = null;
    let isMounted = true;
    let progressInterval: any = null;
    setIsLoading(true);

    loadYouTubeApi().then((YT) => {
      if (!isMounted) return;

      const playerContainer = document.getElementById(`yt-player-${youtubeId}`);
      if (!playerContainer) return;

      activePlayer = new YT.Player(`yt-player-${youtubeId}`, {
        videoId: youtubeId,
        playerVars: {
          controls: bypassShield ? 1 : 0,
          disablekb: bypassShield ? 0 : 1,
          fs: 1,
          modestbranding: 1,
          rel: 0,
          showinfo: 0,
          iv_load_policy: 3,
          playsinline: 1,
          enablejsapi: 1,
          origin: window.location.origin
        },
        events: {
          onReady: (event: any) => {
            if (!isMounted) return;
            ytPlayerRef.current = event.target;
            const dur = event.target.getDuration();
            setDuration(dur);
            setVolume(event.target.getVolume());
            setIsMuted(event.target.isMuted());
            setIsLoading(false);

            // Save player progress on ready if we have a positive duration
            if (dur > 0) {
              const current = event.target.getCurrentTime() || 0;
              saveProgress(current, dur);
            }

            // Set initial parameters safely
            event.target.setVolume(volume);
            if (typeof event.target.setPlaybackRate === 'function') {
              event.target.setPlaybackRate(playbackSpeed);
            }
            
            // Poll for current playback progress
            progressInterval = setInterval(() => {
              if (event.target && typeof event.target.getCurrentTime === 'function') {
                const current = event.target.getCurrentTime();
                const durVal = event.target.getDuration() || duration;
                setCurrentTime(current);
                if (durVal) {
                  saveProgress(current, durVal);
                }
              }
            }, 400);
          },
          onStateChange: (event: any) => {
            if (!isMounted) return;
            // State types: -1 (unstarted), 0 (ended), 1 (playing), 2 (paused), 3 (buffering), 5 (video cued)
            const state = event.data;
            setIsPlaying(state === 1);
            if (state === 3) {
              setIsLoading(true);
            } else {
              setIsLoading(false);
            }
          },
          onError: (event: any) => {
            console.error('YouTube Player Error:', event.data);
            if (!isMounted) return;
            setIsLoading(false);
            if (event.data === 101 || event.data === 150 || event.data === 100 || event.data === 2) {
              setVideoError('หากเป็นวิดีโอส่วนตัว (Private) หรือไม่แสดงรายการ (Unlisted) กรุณากดปุ่มเปิดโมหดเข้าถึงตรงด้านล่าง เพื่อล็อกอินเข้าชมผ่าน YouTube สำเร็จ');
            }
          }
        }
      });
    }).catch(err => {
      console.error('Failed to load YouTube API', err);
      if (isMounted) setIsLoading(false);
    });

    return () => {
      isMounted = false;
      if (progressInterval) clearInterval(progressInterval);
      if (activePlayer && typeof activePlayer.destroy === 'function') {
        try {
          activePlayer.destroy();
        } catch (e) {
          console.error('Error destroying youtube player:', e);
        }
      }
      ytPlayerRef.current = null;
    };
  }, [youtubeId, bypassShield]);

  // Common Controls actions
  const togglePlay = () => {
    if (youtubeId && ytPlayerRef.current) {
      if (isPlaying) {
        ytPlayerRef.current.pauseVideo();
      } else {
        ytPlayerRef.current.playVideo();
      }
    } else if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play().catch(err => {
          console.error('Play prevented:', err);
          setVideoError('เบราว์เซอร์ไม่รองรับการเล่นวิดีโอนี้ (Not Supported)');
        });
      }
    }
  };

  const handleSkip = (seconds: number) => {
    let newTime = currentTime + seconds;
    if (newTime < 0) newTime = 0;
    if (newTime > duration) newTime = duration;
    setCurrentTime(newTime);
    if (youtubeId && ytPlayerRef.current) {
      if (typeof ytPlayerRef.current.seekTo === 'function') {
        ytPlayerRef.current.seekTo(newTime, true);
      }
    } else if (videoRef.current) {
      videoRef.current.currentTime = newTime;
    }
  };

  const handleSpeedChange = (speed: number) => {
    setPlaybackSpeed(speed);
    if (youtubeId && ytPlayerRef.current) {
      if (typeof ytPlayerRef.current.setPlaybackRate === 'function') {
        ytPlayerRef.current.setPlaybackRate(speed);
      }
    } else if (videoRef.current) {
      videoRef.current.playbackRate = speed;
    }
  };

  const handleSeekChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = parseFloat(e.target.value);
    setCurrentTime(time);
    if (youtubeId && ytPlayerRef.current) {
      ytPlayerRef.current.seekTo(time, true);
    } else if (videoRef.current) {
      videoRef.current.currentTime = time;
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const vol = parseInt(e.target.value, 10);
    setVolume(vol);
    setIsMuted(vol === 0);
    if (youtubeId && ytPlayerRef.current) {
      ytPlayerRef.current.setVolume(vol);
      if (vol === 0) ytPlayerRef.current.mute();
      else ytPlayerRef.current.unMute();
    } else if (videoRef.current) {
      videoRef.current.volume = vol / 100;
      videoRef.current.muted = vol === 0;
    }
  };

  const toggleMute = () => {
    const newMuted = !isMuted;
    setIsMuted(newMuted);
    if (youtubeId && ytPlayerRef.current) {
      if (newMuted) {
        ytPlayerRef.current.mute();
      } else {
        ytPlayerRef.current.unMute();
        ytPlayerRef.current.setVolume(volume || 50);
      }
    } else if (videoRef.current) {
      videoRef.current.muted = newMuted;
    }
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().catch((err) => {
        console.error('Fullscreen attempt failed:', err);
      });
    } else {
      document.exitFullscreen();
    }
  };

  const formatTime = (secs: number) => {
    if (isNaN(secs) || secs === Infinity) return '0:00';
    const minutes = Math.floor(secs / 60);
    const seconds = Math.floor(secs % 60);
    return `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
  };

  return (
    <div 
      ref={containerRef}
      onMouseMove={() => setShowControls(true)}
      onMouseLeave={() => isPlaying && setShowControls(false)}
      className="aspect-video w-full bg-black rounded-xl overflow-hidden relative select-none group border border-zinc-800"
      style={{ contentVisibility: 'auto' }}
    >
      {/* 100% Transparent Screen Shield Overlay - blocks all right-clicks, iframe clicks, logo clicks, and copy links */}
      <div 
        onClick={(!videoUrl || videoUrl.includes('drive.google.com')) ? undefined : togglePlay}
        onContextMenu={(e) => e.preventDefault()}
        className={`absolute inset-0 z-20 transition-colors duration-150 ${((!videoUrl || videoUrl.includes('drive.google.com')) && !youtubeId) || bypassShield ? 'pointer-events-none' : 'cursor-pointer pointer-events-auto bg-transparent active:bg-black/15'}`}
      />

      {/* Embedded Dynamic Moving Watermark Layer (Superimposed securely on top of the actual video frame but below custom control bars) */}
      <div
        className="absolute pointer-events-none z-30 transition-all duration-1000 ease-in-out font-mono text-[9px] sm:text-[11px] font-bold text-white/20 bg-black/60 border border-white/5 backdrop-blur-[0.5px] px-2.5 py-1.5 rounded-lg tracking-wider select-none shadow-md flex flex-col items-start"
        style={{ left: `${watermarkPos.x}%`, top: `${watermarkPos.y}%` }}
      >
        <div className="flex items-center space-x-1.5 mb-0.5">
          <span className="w-1.5 h-1.5 bg-red-500 rounded-full animate-ping shrink-0" />
          <span>COPYRIGHT PROTECTED • STUDENT: {currentUser.email} ({currentUser.uid.substring(0, 6).toUpperCase()})</span>
        </div>
        {userIp && <span className="text-[8px] sm:text-[9px] text-zinc-400">IP: {userIp}</span>}
      </div>

      {/* Secondary Static Corner Watermarks */}
      <div className="absolute top-4 left-4 pointer-events-none z-30 opacity-20 font-mono text-[8px] text-zinc-300 uppercase tracking-widest bg-black/40 px-2 py-0.5 rounded flex flex-col items-start gap-0.5">
        <span>LICENSED TO: {currentUser.email}</span>
        {userIp && <span className="text-[7px] opacity-70">IP: {userIp}</span>}
      </div>
      
      {/* Floating Switch for Private/Unlisted playback assistance */}
      {youtubeId ? (
        <div className="absolute top-4 right-4 z-40 pointer-events-auto">
          <button
            type="button"
            onClick={() => {
              setBypassShield(!bypassShield);
              if (videoError) setVideoError(null);
            }}
            className={`px-2.5 py-1.5 rounded-lg text-[10px] font-semibold flex items-center space-x-1.5 shadow-md border backdrop-blur-md transition-all duration-200 cursor-pointer ${
              bypassShield 
                ? 'bg-emerald-600 border-emerald-500 text-white hover:bg-emerald-700' 
                : 'bg-black/80 border-zinc-700 text-zinc-300 hover:text-white hover:border-zinc-500'
            }`}
          >
            <Lock className={`h-3 w-3 ${bypassShield ? 'animate-pulse text-white' : 'text-zinc-400'}`} />
            <span>{bypassShield ? 'เข้าถึงตรงสำหรับคลิปส่วนตัว (เปิดอยู่)' : 'เปิดโหมดคลิปส่วนตัว'}</span>
          </button>
        </div>
      ) : (
        <div className="absolute top-4 right-4 pointer-events-none z-30 opacity-20 font-mono text-[8px] text-zinc-300 uppercase tracking-widest bg-black/40 px-2 py-0.5 rounded">
          SECURE STREAM: OVERLAY RECORD SHIELD
        </div>
      )}

      {/* Content Loader indicator */}
      {(isLoading || isPresigning) && !videoError && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/80 z-40 pointer-events-none">
          <div className="text-center flex flex-col items-center">
            <Loader2 className="h-10 w-10 text-white animate-spin mb-3" />
            <span className="text-xs font-mono text-zinc-400 tracking-wider">กำลังเข้ารหัสสัญญาณสตรีมเพื่อความปลอดภัย...</span>
          </div>
        </div>
      )}

      {/* Error State */}
      {videoError && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/90 z-40">
          <div className="text-center flex flex-col items-center p-6 bg-zinc-900 rounded-2xl border border-red-500/30 max-w-sm mx-4">
            <div className="h-12 w-12 rounded-full bg-red-500/10 flex items-center justify-center mb-3">
              <span className="text-red-500 text-2xl font-bold">!</span>
            </div>
            <h3 className="text-red-400 font-medium mb-3 text-xs leading-relaxed">{videoError}</h3>
            
            {youtubeId && !bypassShield && (
              <button
                type="button"
                onClick={() => {
                  setBypassShield(true);
                  setVideoError(null);
                }}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs py-2 px-3 rounded-lg shadow transition-all cursor-pointer mb-2.5"
              >
                เปิดโหมดเข้าถึงตรงสำหรับคลิปส่วนตัว
              </button>
            )}
          </div>
        </div>
      )}

      {/* Video Media Source Mountings */}
      <div className="w-full h-full relative z-10 select-none overflow-hidden pb-1">
        {youtubeId ? (
          <div className="w-full h-full select-none overflow-hidden hover:opacity-100">
            <div id={`yt-player-${youtubeId}`} className="w-full h-full scale-[1.01]" />
          </div>
        ) : videoUrl && videoUrl.includes('drive.google.com/file/d/') ? (
          <iframe 
            src={`https://drive.google.com/file/d/${videoUrl.match(/\/file\/d\/([a-zA-Z0-9_-]+)/)?.[1] || ''}/preview`}
            width="100%" 
            height="100%" 
            allow="autoplay"
            className="w-full h-full object-contain pointer-events-auto"
            title="Google Drive Video"
          ></iframe>
        ) : (
          <video
            ref={videoRef}
            src={resolvedUrl}
            preload="metadata"
            playsInline
            controls={!!videoError}
            controlsList="nodownload noremoteplayback"
            disablePictureInPicture
            className={`w-full h-full object-contain bg-black select-none ${videoError ? 'pointer-events-auto' : 'pointer-events-none'}`}
          />
        )}
      </div>

      {/* Bottom Custom Playback Bar (Visible when controller active; high-contrast white border styling matching custom requested black and white styles) */}
      {(!youtubeId && (!videoUrl || videoUrl.includes('drive.google.com')) ) ? null : (
      <div 
        className={`absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/90 via-black/60 to-transparent p-3 pt-6 z-30 transition-all duration-300 ease-in-out flex flex-col space-y-2 pointer-events-auto ${
          showControls ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2 pointer-events-none'
        }`}
      >
        {/* Timeline Slider with custom tracks */}
        <div className="flex items-center space-x-2 group/slider">
          <span className="text-[10px] font-mono text-zinc-300 select-none shrink-0">{formatTime(currentTime)}</span>
          <input
            type="range"
            min={0}
            max={duration || 100}
            step={0.1}
            value={currentTime}
            onChange={handleSeekChange}
            className="flex-1 h-1 bg-zinc-700 rounded-lg appearance-none cursor-pointer accent-white hover:accent-zinc-100"
          />
          <span className="text-[10px] font-mono text-zinc-300 select-none shrink-0">{formatTime(duration)}</span>
        </div>

        {/* Playback action items: Clean Black Text / White Box button style layout overlayed or solid monochrome controllers */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2 sm:space-x-3">
            {/* Skip Backward -5s */}
            <button
              onClick={() => handleSkip(-5)}
              type="button"
              className="video-ctrl-btn flex items-center justify-center p-2 rounded-lg bg-white border border-black hover:bg-neutral-200 transition-colors pointer-events-auto shrink-0 w-9 h-9 text-xs font-bold text-black font-mono select-none"
              title="ย้อนกลับ 5 วินาที"
            >
              -5s
            </button>

            {/* Custom styled play button (using original styling override safe context) */}
            <button
              onClick={togglePlay}
              type="button"
              className="video-ctrl-btn flex items-center justify-center p-2 rounded-lg bg-white border border-black hover:bg-neutral-200 transition-colors pointer-events-auto shrink-0 w-9 h-9"
              title={isPlaying ? 'หยุดชั่วคราว' : 'เล่น'}
            >
              {isPlaying ? (
                <Pause className="h-4 w-4 text-black stroke-[3px]" />
              ) : (
                <Play className="h-4 w-4 text-black fill-black" />
              )}
            </button>

            {/* Skip Forward +5s */}
            <button
              onClick={() => handleSkip(5)}
              type="button"
              className="video-ctrl-btn flex items-center justify-center p-2 rounded-lg bg-white border border-black hover:bg-neutral-200 transition-colors pointer-events-auto shrink-0 w-9 h-9 text-xs font-bold text-black font-mono select-none"
              title="ข้ามไป 5 วินาที"
            >
              +5s
            </button>

            {/* Volume controls */}
            <div className="flex items-center space-x-2">
              <button
                onClick={toggleMute}
                type="button"
                className="video-ctrl-btn p-2 rounded-lg bg-white border border-black hover:bg-neutral-200 transition-colors shrink-0 w-9 h-9 flex items-center justify-center pointer-events-auto"
                title={isMuted ? 'เปิดเสียง' : 'ปิดเสียง'}
              >
                {isMuted || volume === 0 ? (
                  <VolumeX className="h-4 w-4 text-black stroke-[2.5px]" />
                ) : (
                  <Volume2 className="h-4 w-4 text-black" />
                )}
              </button>
              <input
                type="range"
                min={0}
                max={100}
                value={isMuted ? 0 : volume}
                onChange={handleVolumeChange}
                className="w-12 sm:w-20 h-1 bg-zinc-700 rounded-lg appearance-none cursor-pointer accent-white"
              />
            </div>
          </div>

          <div className="flex items-center space-x-2 sm:space-x-3">
            {/* Security Indicator Badge */}
            <div className="hidden lg:flex items-center space-x-1 px-2.5 py-1 rounded bg-black/60 border border-zinc-700 text-xs text-zinc-400 font-mono">
              <Shield className="h-3 w-3 text-emerald-500 animate-pulse" />
              <span>คุ้มครองลิขสิทธิ์</span>
            </div>

            {/* Playback Speed Multiplier */}
            <div className="relative pointer-events-auto shrink-0">
              <select
                value={playbackSpeed}
                onChange={(e) => handleSpeedChange(parseFloat(e.target.value))}
                className="h-9 px-1.5 sm:px-2 text-xs font-bold text-black bg-white border border-black rounded-lg cursor-pointer focus:outline-none appearance-none pr-6 sm:pr-8 relative transition-colors hover:bg-neutral-200 text-center font-sans"
                style={{
                  backgroundImage: `url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='black' stroke-width='2.5' stroke-linecap='round' stroke-linejoin='round'><polyline points='6 9 12 15 18 9'></polyline></svg>")`,
                  backgroundRepeat: "no-repeat",
                  backgroundPosition: "right 5px center",
                }}
                title="ความเร็วในการเล่น"
              >
                <option value="0.5">0.5x</option>
                <option value="0.75">0.75x</option>
                <option value="1">1.0x</option>
                <option value="1.25">1.25x</option>
                <option value="1.5">1.5x</option>
                <option value="1.75">1.75x</option>
                <option value="2">2.0x</option>
                <option value="4">4.0x</option>
                <option value="16">16.0x</option>
              </select>
            </div>

            {/* Fullscreen Button */}
            <button
              onClick={toggleFullscreen}
              type="button"
              className="video-ctrl-btn p-2 rounded-lg bg-white border border-black hover:bg-neutral-200 transition-colors shrink-0 w-9 h-9 flex items-center justify-center pointer-events-auto"
              title={isFullscreen ? 'ย่อหน้าจอ' : 'เต็มหน้าจอ'}
            >
              {isFullscreen ? (
                <Minimize2 className="h-4 w-4 text-black" />
              ) : (
                <Maximize2 className="h-4 w-4 text-black" />
              )}
            </button>
          </div>
        </div>
      </div>
      )}
    </div>
  );
}
