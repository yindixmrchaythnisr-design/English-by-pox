import React, { useState, useEffect } from 'react';
import { Course, Lesson, Material, Enrollment, Comment, UserProfile } from '../types';
import { db, handleFirestoreError, OperationType } from '../firebase';
import {
  collection,
  query,
  where,
  orderBy,
  onSnapshot,
  doc,
  addDoc,
  setDoc,
  deleteDoc,
  updateDoc,
  serverTimestamp
} from 'firebase/firestore';
import {
  ArrowLeft,
  Play,
  FileText,
  MessageSquare,
  Users,
  Plus,
  Trash2,
  ExternalLink,
  ChevronRight,
  Sparkles,
  Paperclip,
  CheckCircle,
  Video,
  Shield
} from 'lucide-react';
import { getYouTubeId, formatThaiDate } from '../utils';
import SecureVideoPlayer from './SecureVideoPlayer';

interface CourseDetailProps {
  course: Course;
  currentUser: UserProfile;
  onBack: () => void;
}

export default function CourseDetail({ course, currentUser, onBack }: CourseDetailProps) {
  // Database States
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [materials, setMaterials] = useState<Material[]>([]);
  const [enrollments, setEnrollments] = useState<Enrollment[]>([]);
  const [comments, setComments] = useState<Comment[]>([]);
  
  // App UX States
  const [selectedLesson, setSelectedLesson] = useState<Lesson | null>(null);
  const [activeTab, setActiveTab] = useState<'content' | 'materials' | 'students'>('content');

  // Forms & Modals toggle
  const [showLessonForm, setShowLessonForm] = useState(false);
  const [showMaterialForm, setShowMaterialForm] = useState(false);

  // Lesson Form Input States
  const [lessonTitle, setLessonTitle] = useState('');
  const [lessonDesc, setLessonDesc] = useState('');
  const [lessonVideoUrl, setLessonVideoUrl] = useState('');
  const [videoSourceType, setVideoSourceType] = useState<'youtube' | 'cloud'>('youtube');

  // Supabase/S3 Status for instructor validation
  const [cloudConfigStatus, setCloudConfigStatus] = useState<{
    AWS_ACCESS_KEY_ID_STATUS?: string;
    AWS_SECRET_ACCESS_KEY_STATUS?: string;
    AWS_REGION?: string;
    AWS_S3_BUCKET?: string;
    SUPABASE_URL_STATUS?: string;
    SUPABASE_KEY_STATUS?: string;
    loaded?: boolean;
    error?: string;
  }>({ loaded: false });

  // Fetch private storage connection status for instructors
  useEffect(() => {
    const isInstructorUser = currentUser.role === 'instructor' || course.creatorId === currentUser.uid;
    if (isInstructorUser && showLessonForm) {
      fetch('/api/videos/debug-s3')
        .then(res => res.json())
        .then(data => {
          setCloudConfigStatus({
            ...data,
            loaded: true
          });
        })
        .catch(err => {
          console.error('Error fetching S3/Supabase debug status:', err);
          setCloudConfigStatus({
            loaded: true,
            error: err.message || 'ไม่สามารถเชื่อมต่อเซิร์ฟเวอร์เพื่อตรวจสอบ Secrets หลังบ้านได้'
          });
        });
    }
  }, [currentUser.role, course.creatorId, currentUser.uid, showLessonForm]);

  // Material Form Input States
  const [materialTitle, setMaterialTitle] = useState('');
  const [materialDesc, setMaterialDesc] = useState('');
  const [materialUrl, setMaterialUrl] = useState('');
  const [materialType, setMaterialType] = useState<'pdf' | 'doc' | 'link' | 'slide' | 'archive'>('pdf');
  const [uploadMethod, setUploadMethod] = useState<'file' | 'link'>('file');
  const [selectedFileName, setSelectedFileName] = useState('');
  const [fileReadStatus, setFileReadStatus] = useState<string | null>(null);

  // Comment Input State
  const [commentText, setCommentText] = useState('');
  const [activeReplyId, setActiveReplyId] = useState<string | null>(null);
  const [replyTextMap, setReplyTextMap] = useState<{ [commentId: string]: string }>({});

  // Course License Activation States
  const [activationKey, setActivationKey] = useState('');
  const [activationError, setActivationError] = useState<string | null>(null);
  const [isActivating, setIsActivating] = useState(false);
  const [userIp, setUserIp] = useState<string>('กำลังตรวจสอบ...');

  // Local storage progress state for student videos tracking
  const [progressDict, setProgressDict] = useState<Record<string, any>>({});

  useEffect(() => {
    const handleStorage = () => {
      const uId = currentUser?.uid;
      if (!uId || !course?.id) return;
      const key = `course_progress_${uId}_${course.id}`;
      try {
        const saved = localStorage.getItem(key);
        if (saved) {
          setProgressDict(JSON.parse(saved));
        }
      } catch (e) {
        console.error(e);
      }
    };

    handleStorage();
    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, [currentUser?.uid, course?.id]);

  const isInstructor = currentUser.role === 'instructor' || course.creatorId === currentUser.uid;
  const userEnrollment = enrollments.find(e => e.userId === currentUser.uid);
  const isActivated = isInstructor || (userEnrollment && userEnrollment.isActivated === true);

  // Dynamic Floating Watermark Positioning to prevent unauthorized screen capture
  const [watermarkPos, setWatermarkPos] = useState({ x: 30, y: 20 });

  useEffect(() => {
    fetch('https://api.ipify.org?format=json')
      .then(res => res.json())
      .then(data => setUserIp(data.ip))
      .catch(() => setUserIp('ไม่ทราบ IP'));
  }, []);

  useEffect(() => {
    if (!selectedLesson || !isActivated) return;
    
    // Change watermark position slowly every 5 seconds to discourage recording crop-outs
    const interval = setInterval(() => {
      const randomX = Math.floor(Math.random() * 55) + 15; // 15% to 70% range
      const randomY = Math.floor(Math.random() * 55) + 15; // 15% to 70% range
      setWatermarkPos({ x: randomX, y: randomY });
    }, 5000);
    
    return () => clearInterval(interval);
  }, [selectedLesson?.id, isActivated]);

  // License Key Activation Function
  const handleActivateLicense = async (e: React.FormEvent) => {
    e.preventDefault();
    setActivationError(null);
    if (!activationKey.trim()) return;

    const expectedKey = `BLUECLASS-${course.id.substring(7, 12).toUpperCase()}`;
    if (activationKey.trim().toUpperCase() !== expectedKey) {
      setActivationError(`รหัสสิทธิ์ไม่ถูกต้อง! คีย์ทดสอบของคุณคือ: "${expectedKey}" (โปรดคัดลอกมาวางเพื่อเรียนรู้ได้เลยครับ)`);
      return;
    }

    setIsActivating(true);
    try {
      const enrollmentId = `${currentUser.uid}_${course.id}`;
      const enrollmentRef = doc(db, 'enrollments', enrollmentId);
      await updateDoc(enrollmentRef, { isActivated: true });
    } catch (error) {
      console.error("Activation failed:", error);
      setActivationError("ไม่พบข้อมูลการลงทะเบียนวิชานี้ หรือเกิดปัญหาการเชื่อมต่อกับฐานข้อมูลคลาวด์!");
    } finally {
      setIsActivating(false);
    }
  };

  // 1. Fetch Lessons
  useEffect(() => {
    const q = query(
      collection(db, 'lessons'),
      where('courseId', '==', course.id),
      orderBy('order', 'asc')
    );
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetched: Lesson[] = [];
      snapshot.forEach((doc) => {
        fetched.push({ ...doc.data() as Lesson, id: doc.id });
      });
      setLessons(fetched);
      if (fetched.length > 0 && !selectedLesson) {
        setSelectedLesson(fetched[0]);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'lessons');
    });
    return () => unsubscribe();
  }, [course.id]);

  // 2. Fetch Materials
  useEffect(() => {
    const q = query(
      collection(db, 'materials'),
      where('courseId', '==', course.id),
      orderBy('createdAt', 'desc')
    );
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetched: Material[] = [];
      snapshot.forEach((doc) => {
        fetched.push({ ...doc.data() as Material, id: doc.id });
      });
      setMaterials(fetched);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'materials');
    });
    return () => unsubscribe();
  }, [course.id]);

  // 3. Fetch Enrollments
  useEffect(() => {
    const q = query(
      collection(db, 'enrollments'),
      where('courseId', '==', course.id)
    );
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetched: Enrollment[] = [];
      snapshot.forEach((doc) => {
        fetched.push({ ...doc.data() as Enrollment, id: doc.id });
      });
      setEnrollments(fetched);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'enrollments');
    });
    return () => unsubscribe();
  }, [course.id]);

  // 4. Fetch Comments for active Lesson
  useEffect(() => {
    if (!selectedLesson) return;
    const q = query(
      collection(db, 'comments'),
      where('lessonId', '==', selectedLesson.id),
      orderBy('createdAt', 'asc')
    );
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetched: Comment[] = [];
      snapshot.forEach((doc) => {
        fetched.push({ ...doc.data() as Comment, id: doc.id });
      });
      setComments(fetched);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'comments');
    });
    return () => unsubscribe();
  }, [selectedLesson?.id]);

  // Add Lesson
  const handleAddLesson = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!lessonTitle.trim() || !lessonVideoUrl.trim()) return;

    try {
      const lessonId = `lesson_${Date.now()}`;
      const videoType = getYouTubeId(lessonVideoUrl) ? 'youtube' : 'direct';
      
      const newLesson = {
        id: lessonId,
        courseId: course.id,
        title: lessonTitle.trim(),
        description: lessonDesc.trim(),
        videoUrl: lessonVideoUrl.trim(),
        videoType,
        order: lessons.length + 1,
        createdAt: new Date().toISOString()
      };

      await setDoc(doc(db, 'lessons', lessonId), newLesson);
      
      setLessonTitle('');
      setLessonDesc('');
      setLessonVideoUrl('');
      setShowLessonForm(false);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'lessons');
    }
  };

  // Handle local file selection
  const handleLocalFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFileReadStatus('กำลังอ่านข้อมูลไฟล์...');
    
    // Check if file size is above 1MB (1,048,576 bytes)
    if (file.size > 1024 * 1024) {
      setFileReadStatus('ขนาดไฟล์เกินกว่า 1MB แนะนำให้เลือกวิธีระบุลิงก์ด้านบนแทน');
      return;
    }

    if (!materialTitle.trim()) {
      const baseName = file.name.substring(0, file.name.lastIndexOf('.')) || file.name;
      setMaterialTitle(baseName);
    }

    // Auto set fileType based on extension
    const ext = file.name.split('.').pop()?.toLowerCase() || '';
    if (ext === 'pdf') {
      setMaterialType('pdf');
    } else if (['doc', 'docx', 'txt', 'rtf'].includes(ext)) {
      setMaterialType('doc');
    } else if (['ppt', 'pptx', 'key'].includes(ext)) {
      setMaterialType('slide');
    } else if (['zip', 'rar', '7z', 'tar', 'gz'].includes(ext)) {
      setMaterialType('archive');
    } else {
      setMaterialType('link');
    }

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setMaterialUrl(reader.result);
        setSelectedFileName(file.name);
        setFileReadStatus(`เลือกไฟล์สำเร็จ (${(file.size / 1024).toFixed(1)} KB)`);
      } else {
        setFileReadStatus('เกิดข้อผิดพลาดในการโหลดไฟล์');
      }
    };
    reader.onerror = () => {
      setFileReadStatus('ไม่สามารถเปิดอ่านไฟล์ได้');
    };
    reader.readAsDataURL(file);
  };

  // Add Material
  const handleAddMaterial = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!materialTitle.trim() || !materialUrl.trim()) return;

    try {
      const materialId = `material_${Date.now()}`;
      const newMaterial = {
        id: materialId,
        courseId: course.id,
        lessonId: selectedLesson?.id || '',
        title: materialTitle.trim(),
        description: materialDesc.trim(),
        fileUrl: materialUrl.trim(),
        fileType: materialType,
        uploadedBy: currentUser.uid,
        createdAt: new Date().toISOString()
      };

      await setDoc(doc(db, 'materials', materialId), newMaterial);

      setMaterialTitle('');
      setMaterialDesc('');
      setMaterialUrl('');
      setMaterialType('pdf');
      setSelectedFileName('');
      setFileReadStatus(null);
      setUploadMethod('file');
      setShowMaterialForm(false);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'materials');
    }
  };

  // Custom Confirm Modal State
  const [confirmDelete, setConfirmDelete] = useState<{ id: string, type: 'lesson' | 'material' | 'comment' | 'student' } | null>(null);

  // Add Comment
  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim() || !selectedLesson) return;

    try {
      const commentId = `comment_${Date.now()}`;
      const newComment = {
        id: commentId,
        courseId: course.id,
        lessonId: selectedLesson.id,
        userId: currentUser.uid,
        userName: currentUser.name,
        userPhoto: currentUser.photoURL,
        content: commentText.trim(),
        createdAt: new Date().toISOString()
      };

      await setDoc(doc(db, 'comments', commentId), newComment);
      setCommentText('');

      // Notify course creator (instructor/teacher) if someone else comments
      if (currentUser.uid !== course.creatorId) {
        const notifId = `notif_${Date.now()}`;
        const notification = {
          id: notifId,
          recipientId: course.creatorId,
          senderId: currentUser.uid,
          senderName: currentUser.name,
          senderPhotoURL: currentUser.photoURL || '',
          title: `คำถาม/ข้อเสนอแนะใหม่ในเรื่อง ${selectedLesson.title}`,
          content: `${currentUser.name} ได้แสดงความคิดเห็น: "${newComment.content.substring(0, 60)}${newComment.content.length > 60 ? '...' : ''}"`,
          courseId: course.id,
          lessonId: selectedLesson.id,
          commentId: commentId,
          isRead: false,
          createdAt: new Date().toISOString()
        };
        await setDoc(doc(db, 'notifications', notifId), notification);
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'comments');
    }
  };

  // Add Threaded Reply
  const handleAddReply = async (commentId: string) => {
    const replyText = replyTextMap[commentId];
    if (!replyText || !replyText.trim() || !selectedLesson) return;

    try {
      const replyId = `reply_${Date.now()}`;
      const newReply = {
        id: replyId,
        courseId: course.id,
        lessonId: selectedLesson.id,
        userId: currentUser.uid,
        userName: currentUser.name,
        userPhoto: currentUser.photoURL,
        content: replyText.trim(),
        createdAt: new Date().toISOString(),
        parentId: commentId
      };

      await setDoc(doc(db, 'comments', replyId), newReply);
      
      // Reset reply input state
      setReplyTextMap(prev => ({ ...prev, [commentId]: '' }));
      setActiveReplyId(null);

      // Fetch the parent comment in state or local lookup to notify its creator
      const parentComment = comments.find(c => c.id === commentId);
      
      // 1. Notify the original comment poster (student/teacher) if it was replied by someone else
      if (parentComment && parentComment.userId !== currentUser.uid) {
        const notifId = `notif_${Date.now()}`;
        const notification = {
          id: notifId,
          recipientId: parentComment.userId,
          senderId: currentUser.uid,
          senderName: currentUser.name,
          senderPhotoURL: currentUser.photoURL || '',
          title: currentUser.role === 'instructor' ? `ครูผู้สอนได้เข้ามาตอบข้อสงสัยของคุณแล้ว` : `มีผู้ตอบกลับความคิดเห็นของคุณ`,
          content: `${currentUser.name}: "${newReply.content.substring(0, 60)}${newReply.content.length > 60 ? '...' : ''}"`,
          courseId: course.id,
          lessonId: selectedLesson.id,
          commentId: replyId,
          isRead: false,
          createdAt: new Date().toISOString()
        };
        await setDoc(doc(db, 'notifications', notifId), notification);
      }

      // 2. Also notify the course creator (instructor) if a student is replying, and it's not the instructor's own post
      if (currentUser.uid !== course.creatorId && (!parentComment || parentComment.userId !== course.creatorId)) {
        const notifIdT = `notif_t_${Date.now()}`;
        const notificationT = {
          id: notifIdT,
          recipientId: course.creatorId,
          senderId: currentUser.uid,
          senderName: currentUser.name,
          senderPhotoURL: currentUser.photoURL || '',
          title: `มีการตอบกลับใหม่ในหัวข้อบทเรียน ${selectedLesson.title}`,
          content: `${currentUser.name}: "${newReply.content.substring(0, 60)}${newReply.content.length > 60 ? '...' : ''}"`,
          courseId: course.id,
          lessonId: selectedLesson.id,
          commentId: replyId,
          isRead: false,
          createdAt: new Date().toISOString()
        };
        await setDoc(doc(db, 'notifications', notifIdT), notificationT);
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'comments');
    }
  };

  // Delete Lesson
  const handleDeleteLesson = async (lessonDocId: string) => {
    try {
      await deleteDoc(doc(db, 'lessons', lessonDocId));
      if (selectedLesson?.id === lessonDocId) {
        setSelectedLesson(null);
      }
    } catch (err: any) {
      alert(`ไม่สามารถลบบทเรียนได้: ${err?.message || 'ข้อผิดพลาดของระบบ'}`);
      handleFirestoreError(err, OperationType.DELETE, 'lessons');
    } finally {
      setConfirmDelete(null);
    }
  };

  // Delete Material
  const handleDeleteMaterial = async (materialDocId: string) => {
    try {
      await deleteDoc(doc(db, 'materials', materialDocId));
    } catch (err: any) {
      alert(`ไม่สามารถลบเอกสารได้: ${err?.message || 'ข้อผิดพลาดของระบบ'}`);
      handleFirestoreError(err, OperationType.DELETE, 'materials');
    } finally {
      setConfirmDelete(null);
    }
  };

  // Delete Comment
  const handleDeleteComment = async (commentDocId: string) => {
    try {
      await deleteDoc(doc(db, 'comments', commentDocId));
    } catch (err: any) {
      handleFirestoreError(err, OperationType.DELETE, 'comments');
    } finally {
      setConfirmDelete(null);
    }
  };

  // Delete Student
  const handleDeleteStudent = async (enrollmentDocId: string) => {
    try {
      await deleteDoc(doc(db, 'enrollments', enrollmentDocId));
    } catch (err: any) {
      alert(`ไม่สามารถลบนักเรียนได้: ${err?.message || 'ข้อผิดพลาดของระบบ'}`);
      handleFirestoreError(err, OperationType.DELETE, 'enrollments');
    } finally {
      setConfirmDelete(null);
    }
  };

  // Helper video rendering
  const ytId = selectedLesson ? getYouTubeId(selectedLesson.videoUrl) : null;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col space-y-6" id="classroom-panel">
      
      {/* Global SVG Definitions for Gradients */}
      <svg width="0" height="0" className="absolute pointer-events-none">
        <defs>
          <linearGradient id="icon-blue-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#818cf8" />
            <stop offset="50%" stopColor="#3b82f6" />
            <stop offset="100%" stopColor="#2563eb" />
          </linearGradient>
        </defs>
      </svg>
      
      {/* Header Panel styled as Google Classroom */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-4 rounded-xl border border-gray-200 shadow-3xs">
        <div className="flex items-center space-x-3">
          <button
            onClick={onBack}
            className="p-2 hover:bg-zinc-100 text-zinc-600 rounded-lg transition-all border border-gray-200 cursor-pointer"
            id="btn-back"
          >
            <ArrowLeft className="h-4.5 w-4.5" />
          </button>
          <div className="text-left">
            <div className="flex items-center space-x-2">
              <h1 className="font-sans font-medium text-lg text-zinc-800 line-clamp-1">
                {course.title}
              </h1>
            </div>
            <p className="text-[11px] text-zinc-400 font-sans mt-0.5">
              สร้างโดยผู้สอน: {course.creatorName} • ({course.creatorEmail})
            </p>
          </div>
        </div>

        {/* Custom tabs resembling Google Classroom Navigation (Stream, Classwork, People) */}
        <div className="flex bg-zinc-100 p-1 rounded-lg">
          <button
            onClick={() => setActiveTab('content')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md text-xs font-semibold separation-line transition-all cursor-pointer ${activeTab === 'content' ? 'bg-white shadow-3xs text-blue-600' : 'text-zinc-500 hover:text-zinc-700'}`}
          >
            <Video className="h-3.5 w-3.5" />
            <span>กระดานและบทเรียนต์</span>
          </button>
          <button
            onClick={() => setActiveTab('materials')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md text-xs font-semibold separation-line transition-all cursor-pointer ${activeTab === 'materials' ? 'bg-white shadow-3xs text-blue-600' : 'text-zinc-500 hover:text-zinc-700'}`}
          >
            <FileText className="h-3.5 w-3.5" />
            <span>ใบงาน & ชีตเรียน ({materials.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('students')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition-all cursor-pointer ${activeTab === 'students' ? 'bg-white shadow-3xs text-blue-600' : 'text-zinc-500 hover:text-zinc-700'}`}
          >
            <Users className="h-3.5 w-3.5" />
            <span>สมาชิกชั้นเรียน ({enrollments.length})</span>
          </button>
        </div>
      </div>

      {/* Main Grid Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left column sidebar lists - Lessons */}
        <div className="lg:col-span-4 bg-white rounded-xl border border-gray-200 p-4 space-y-4 shadow-3xs text-left">
          <div className="flex justify-between items-center pb-2 border-b border-gray-100">
            <h2 className="font-sans font-semibold text-xs text-zinc-700 flex items-center space-x-2.5 uppercase tracking-wide">
              <div className="h-6 w-6 rounded-md bg-gradient-to-br from-[#B8E5FC] to-blue-50 flex items-center justify-center text-black border border-[#B8E5FC]/60 shadow-xs shrink-0">
                <Play className="h-3.5 w-3.5 fill-black" strokeWidth={1.5} />
              </div>
              <span>หัวข้อบทเรียนทั้งหมด ({lessons.length})</span>
            </h2>
            {isInstructor && (
              <button
                onClick={() => setShowLessonForm(true)}
                className="p-1 bg-blue-50 hover:bg-blue-100 text-blue-600 rounded border border-blue-200 transition-colors cursor-pointer"
                id="btn-add-lesson-modal"
                title="เพิ่มวิดีโอบทเรียน"
              >
                <Plus className="h-4.5 w-4.5" />
              </button>
            )}
          </div>

          {/* Lesson catalog */}
          {lessons.length === 0 ? (
            <div className="py-8 text-center text-xs text-zinc-400">
              ยังไม่มีกิจกรรมและบทเรียนในห้องเรียนนี้
            </div>
          ) : (
            <div className="space-y-1.5 max-h-[400px] overflow-y-auto pr-1">
              {lessons.map((lesson, idx) => {
                const record = progressDict[lesson.id];
                const hasVideo = !!lesson.videoUrl;
                return (
                  <div
                    key={lesson.id}
                    onClick={() => setSelectedLesson(lesson)}
                    className={`group flex flex-col p-3 rounded-lg cursor-pointer transition-all border space-y-1.5 ${selectedLesson?.id === lesson.id ? 'bg-blue-50/70 border-blue-300 text-blue-700 shadow-3xs' : 'border-zinc-100 hover:bg-zinc-50 text-zinc-600'}`}
                  >
                    <div className="flex items-center justify-between w-full">
                      <div className="flex items-center space-x-2 w-full pr-2 overflow-hidden">
                        <span className="font-mono text-[10px] bg-zinc-100 text-zinc-500 group-hover:bg-white px-2 py-0.5 rounded font-bold shrink-0">
                          {idx + 1}
                        </span>
                        <span className="text-xs font-semibold font-sans truncate">{lesson.title}</span>
                      </div>
                      
                      {isInstructor && (
                        <button
                          onClick={(e) => { e.stopPropagation(); setConfirmDelete({ id: lesson.id, type: 'lesson' }); }}
                          className="p-1 text-zinc-300 hover:text-red-500 rounded transition-colors hover:bg-red-50 cursor-pointer pointer-events-auto shrink-0"
                          id={`btn-delete-lesson-${lesson.id}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      )}
                    </div>

                    {/* Progress tracking bar on lesson sidebar option */}
                    {hasVideo && !isInstructor && (
                      <div className="w-full pl-7 pt-0.5 space-y-1">
                        <div className="flex justify-between items-center text-[9px] font-sans text-neutral-500">
                          <span>
                            {record ? (
                              <span className="font-semibold text-emerald-600">เรียนแล้ว {record.percentage}%</span>
                            ) : (
                              <span>ยังไม่ได้เรียน</span>
                            )}
                          </span>
                          <span>
                            {record ? (
                              record.percentage >= 100 ? 'เสร็จสิ้น' : `เหลืออีกประมาณ ${Math.max(0, Math.ceil(record.timeLeftSeconds / 60))} นาที`
                            ) : (
                              'ยังไม่เริ่มเรียนคลิป'
                            )}
                          </span>
                        </div>
                        <div className="w-full h-1 bg-neutral-100 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-emerald-500 rounded-full transition-all duration-300"
                            style={{ width: `${record ? record.percentage : 0}%` }}
                          />
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {/* Additional Quick stats or Info */}
          <div className="bg-zinc-50 p-3.5 rounded-lg border border-gray-100 text-xs">
            <span className="font-semibold text-zinc-700 block mb-1">สรุปเอกสารเด่นล่าสุด</span>
            {materials.length === 0 ? (
              <span className="text-zinc-400 text-[10px] block font-sans">ไม่มีการอัปโหลดใบงานวิชาในขณะนี้</span>
            ) : (
              <div className="space-y-1">
                {materials.slice(0, 3).map((mat) => (
                  <a
                    key={mat.id}
                    href={mat.fileUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center space-x-1 text-2xs text-blue-600 hover:underline truncate"
                  >
                    <Paperclip className="h-3 w-3 shrink-0" />
                    <span className="truncate">{mat.title}</span>
                  </a>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Central main workspace content */}
        <div className="lg:col-span-8 flex flex-col space-y-6">
          
          {/* Active Tab rendering */}
          {activeTab === 'content' && (
            <div className="bg-white rounded-xl border border-gray-200 p-5 shadow-3xs text-left space-y-5">
              {!isActivated ? (
                /* LICENSE KEY ENTRY FORM OVERLAY */
                <div className="p-4 sm:p-6 text-center space-y-6 max-w-lg mx-auto my-4">
                  <div className="h-16 w-16 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
                    <Play className="h-6 w-6 text-blue-500 fill-blue-500 animate-pulse" />
                  </div>
                  
                  <div className="space-y-2">
                    <h3 className="font-sans font-semibold text-base text-zinc-800">
                      ยืนยันสิทธิ์เข้าห้องเรียน (Class License Activation)
                    </h3>
                    <p className="text-xs text-zinc-500 leading-relaxed font-sans px-2">
                      บทเรียนออนไลน์นี้สงวนสิทธิ์การเข้าเรียนและวิดีโอคลิปให้กับนักเรียนที่มีรหัสสิทธิ์เข้าถึง (License Key) ที่ได้รับอนุญาตจากอาจารย์ผู้สอนของรายวิชานี้เท่านั้น
                    </p>
                  </div>

                  <form onSubmit={handleActivateLicense} className="space-y-3.5 text-left">
                    <div className="space-y-1.5">
                      <label className="text-3xs uppercase font-bold text-zinc-400 block tracking-wider">ป้อนคีย์ลิขสิทธิ์ประจำวิชา</label>
                      <input
                        type="text"
                        value={activationKey}
                        onChange={(e) => setActivationKey(e.target.value)}
                        placeholder="เช่น BLUECLASS-XXXXX"
                        className="w-full bg-zinc-50 border border-zinc-200 focus:border-blue-500 focus:bg-white rounded-lg px-3 py-2 text-xs text-zinc-800 outline-none transition-all font-mono font-bold placeholder:text-zinc-400"
                        required
                      />
                    </div>

                    {activationError && (
                      <p className="text-3xs font-semibold text-red-500 animate-bounce leading-normal">
                        {activationError}
                      </p>
                    )}

                    <button
                      type="submit"
                      disabled={isActivating}
                      className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300 text-white py-2 px-4 rounded-lg text-xs font-semibold shadow-3xs transition-all duration-200 cursor-pointer flex items-center justify-center space-x-1"
                      id="btn-activate-license-submit"
                    >
                      {isActivating ? (
                        <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      ) : (
                        <span>ตรวจสอบรหัสและปลดล็อกบทเรียนท์</span>
                      )}
                    </button>
                  </form>

                  {/* Test reference indicator */}
                  <div className="p-3.5 bg-yellow-50 border border-yellow-104 border-yellow-100 rounded-lg text-left space-y-1.5">
                    <span className="text-[10px] bg-yellow-100 text-yellow-850 text-yellow-850 px-2 py-0.5 rounded font-bold uppercase tracking-wider">
                      คีย์สำหรับบทเรียนทดสอบระบบ (Demo Key)
                    </span>
                    <div className="text-[11px] text-yellow-850 leading-normal font-sans">
                      คุณครูสามารถแชร์คีย์นี้ให้กับนักเรียน คีย์ประจำวิชาถอดรหัสปลดบล็อกในชั้นเรียนนี้คือ &nbsp;
                      <code className="bg-yellow-200 px-1.5 py-0.5 rounded font-mono font-bold select-all">
                        BLUECLASS-{course.id.substring(7, 12).toUpperCase()}
                      </code>
                    </div>
                  </div>
                </div>
              ) : selectedLesson ? (
                <>
                  {/* Secure Custom Full-Coverage Video Player with Watermarks & Click Shield Overlay */}
                  <SecureVideoPlayer 
                    videoUrl={selectedLesson.videoUrl || undefined} 
                    youtubeId={ytId || undefined} 
                    currentUser={currentUser} 
                    title={selectedLesson.title} 
                    userIp={userIp}
                    courseId={course.id}
                    lessonId={selectedLesson.id}
                  />

                  {/* Safety Status Info Badge */}
                  <div className="flex items-center space-x-1.5 text-[10px] text-zinc-500 bg-zinc-50 border border-zinc-200 rounded-lg px-3 py-1.5 self-start inline-flex">
                    <Shield className="h-3.5 w-3.5 text-emerald-600 animate-pulse shrink-0" />
                    <span className="font-sans">
                      ระบบป้องกันลิขสิทธิ์ฝังลายน้ำแบบพลวัต (Dynamic Watermark) และ Click-Shield ป้องกันการแคปเจอร์/เข้าถึงลิงก์ ทำงานร่วมกับ บัญชี: <span className="font-semibold text-zinc-700">{currentUser.email}</span> (IP: <span className="font-semibold text-zinc-700">{userIp}</span>) เพื่อคุ้มครองลิขสิทธิ์ของวิทยากร
                    </span>
                  </div>

                  {/* Header detail */}
                  <div>
                    <h2 className="font-sans font-medium text-lg text-zinc-800 flex items-center space-x-2.5">
                      <div className="h-7 w-7 rounded-lg bg-gradient-to-br from-[#B8E5FC] to-blue-50 flex items-center justify-center text-black border border-[#B8E5FC]/60 shadow-xs shrink-0">
                        <Sparkles className="h-4 w-4" strokeWidth={1.5} />
                      </div>
                      <span>{selectedLesson.title}</span>
                    </h2>
                    <p className="text-xs text-zinc-500 leading-relaxed font-sans mt-2 whitespace-pre-line">
                      {selectedLesson.description || 'ไม่มีคำอธิบายเพิ่มเติมสำหรับบทเรียนย่อยนี้'}
                    </p>
                  </div>

                  {/* Lesson materials linking to PDF/doc */}
                  <div className="pt-4 border-t border-gray-100">
                    <h3 className="font-sans font-semibold text-xs text-zinc-700 mb-3 flex items-center space-x-2">
                      <div className="h-5 w-5 rounded-md bg-gradient-to-br from-[#B8E5FC] to-blue-50 flex items-center justify-center text-black border border-[#B8E5FC]/60 shadow-xs shrink-0">
                        <Paperclip className="h-3 w-3" strokeWidth={1.5} />
                      </div>
                      <span>สื่อ / เอกสารประกอบการเรียนประกอบวิดีโอนี้</span>
                    </h3>
                    
                    {materials.filter(m => m.lessonId === selectedLesson.id).length === 0 ? (
                      <p className="text-2xs text-zinc-400">บทความย่อยนี้ยังไม่มีการแนบไฟล์เนื้อหาเพิ่มเติม</p>
                    ) : (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                        {materials.filter(m => m.lessonId === selectedLesson.id).map((material) => (
                          <div
                            key={material.id}
                            className="bg-zinc-50 hover:bg-zinc-100/70 border border-gray-200 p-3 rounded-lg flex items-center justify-between transition-all"
                          >
                            <div className="flex items-center space-x-2 truncate">
                              <FileText className="h-4 w-4 text-blue-600 shrink-0" />
                              <div className="truncate text-left">
                                <p className="text-xs font-semibold text-zinc-800 truncate" title={material.title}>
                                  {material.title}
                                </p>
                                <p className="text-[10px] text-zinc-400 bg-white border border-gray-100 py-0.5 px-1.5 rounded inline-block">
                                  {material.fileType.toUpperCase()}
                                </p>
                              </div>
                            </div>
                            <a
                              href={material.fileUrl}
                              target="_blank"
                              rel="noreferrer"
                              className="p-1 text-blue-600 hover:text-blue-700 hover:bg-blue-50 rounded transition-colors shrink-0 cursor-pointer"
                            >
                              <ExternalLink className="h-4 w-4" />
                            </a>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Discussion Comments section */}
                  <div className="pt-6 border-t border-gray-100 text-left space-y-4">
                    <h3 className="font-sans font-semibold text-xs text-zinc-700 flex items-center space-x-2">
                      <div className="h-5 w-5 rounded-md bg-gradient-to-br from-[#B8E5FC] to-blue-50 flex items-center justify-center text-black border border-[#B8E5FC]/60 shadow-xs shrink-0">
                        <MessageSquare className="h-3 w-3" strokeWidth={1.5} />
                      </div>
                      <span>ความคิดเห็นในชั้นเรียน ({comments.length})</span>
                    </h3>

                    {/* Write comment */}
                    <form onSubmit={handleAddComment} className="flex gap-2">
                      <input
                        type="text"
                        value={commentText}
                        onChange={(e) => setCommentText(e.target.value)}
                        placeholder="เพิ่มความคิดเห็นในชั้นเรียน..."
                        className="flex-1 bg-zinc-50 border border-gray-250 border-gray-200 focus:border-blue-500 focus:bg-white rounded-lg px-3 py-2 text-xs text-zinc-800 outline-none transition-all placeholder:text-zinc-450"
                        maxLength={500}
                        required
                      />
                      <button
                        type="submit"
                        className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
                        id="btn-send-comment"
                      >
                        ส่ง
                      </button>
                    </form>

                    {/* Comments list */}
                    <div className="space-y-4 max-h-[400px] overflow-y-auto pr-1 pt-1">
                      {comments.filter(c => !c.parentId).length === 0 ? (
                        <p className="text-[11px] text-zinc-400 text-center py-4">
                          ยังไม่มีข้อความตอบกลับในวิดีโอนี้ ร่วมเขียนคอมเมนต์หรือสอบถามได้เลยนะครับ!
                        </p>
                      ) : (
                        comments.filter(c => !c.parentId).map((comment) => {
                          const childReplies = comments.filter(c => c.parentId === comment.id);
                          return (
                            <div key={comment.id} className="space-y-3 border-b border-zinc-100 pb-3 last:border-0 last:pb-0">
                              {/* Parent Comment */}
                              <div className={`p-3 rounded-lg flex items-start justify-between border ${comment.userId === currentUser.uid ? 'bg-blue-50/20 border-blue-100 animate-fade-in' : 'bg-zinc-50/70 border-zinc-200 animate-fade-in'}`}>
                                <div className="flex space-x-2.5 w-full">
                                  <img
                                    referrerPolicy="no-referrer"
                                    src={comment.userPhoto || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=80&q=80'}
                                    alt={comment.userName}
                                    className="h-7 w-7 rounded-full border border-gray-200 object-cover mt-0.5 shrink-0"
                                  />
                                  <div className="text-left flex-1 min-w-0">
                                    <div className="flex items-center space-x-2 flex-wrap">
                                      <span className="text-2xs font-bold text-slate-705">{comment.userName}</span>
                                      {comment.userId === course.creatorId && (
                                        <span className="text-[9px] bg-blue-100 text-blue-700 px-1.5 py-0.2 rounded-full font-bold">ครูผู้สอน</span>
                                      )}
                                      <span className="text-[10px] text-slate-400 font-sans">{formatThaiDate(comment.createdAt)}</span>
                                    </div>
                                    <p className="text-xs text-slate-600 font-sans mt-1 break-words leading-relaxed">
                                      {comment.content}
                                    </p>
                                    
                                    {/* Action items underneath parent comment */}
                                    <div className="flex items-center space-x-3 mt-2">
                                      <button
                                        onClick={() => {
                                          setActiveReplyId(activeReplyId === comment.id ? null : comment.id);
                                          setReplyTextMap(prev => ({ ...prev, [comment.id]: '' }));
                                        }}
                                        className="text-[10px] text-blue-650 hover:text-blue-700 font-semibold cursor-pointer transition-colors"
                                      >
                                        ตอบกลับ
                                      </button>
                                    </div>
                                  </div>
                                </div>

                                {/* Delete by owner or course creator */}
                                {(comment.userId === currentUser.uid || isInstructor) && (
                                  <button
                                    onClick={() => setConfirmDelete({ id: comment.id, type: 'comment' })}
                                    className="text-slate-405 hover:text-red-500 p-1 rounded-md transition-colors hover:bg-red-50 shrink-0 cursor-pointer"
                                    id={`btn-delete-comment-${comment.id}`}
                                  >
                                    <Trash2 className="h-3 w-3" />
                                  </button>
                                )}
                              </div>

                              {/* Nested Replies */}
                              {childReplies.length > 0 && (
                                <div className="pl-6 sm:pl-8 space-y-2.5 border-l border-blue-50 ml-3.5 sm:ml-4">
                                  {childReplies.map((reply) => (
                                    <div
                                      key={reply.id}
                                      className={`p-2.5 rounded-lg flex items-start justify-between border ${reply.userId === currentUser.uid ? 'bg-blue-50/20 border-blue-100 animate-fade-in' : reply.userId === course.creatorId ? 'bg-amber-50/20 border-amber-100 animate-fade-in' : 'bg-zinc-50/40 border-zinc-200 animate-fade-in'}`}
                                    >
                                      <div className="flex space-x-2 w-full">
                                        <img
                                          referrerPolicy="no-referrer"
                                          src={reply.userPhoto || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=80&q=80'}
                                          alt={reply.userName}
                                          className="h-6 w-6 rounded-full border border-gray-200 object-cover mt-0.5 shrink-0"
                                        />
                                        <div className="text-left flex-1 min-w-0">
                                          <div className="flex items-center space-x-1.5 flex-wrap">
                                            <span className="text-[10px] font-bold text-slate-705">{reply.userName}</span>
                                            {reply.userId === course.creatorId && (
                                              <span className="text-[9px] bg-amber-100 text-amber-800 px-1.5 py-0.2 rounded-full font-bold">ครูผู้สอน</span>
                                            )}
                                            <span className="text-[9px] text-slate-400">{formatThaiDate(reply.createdAt)}</span>
                                          </div>
                                          <p className="text-xs text-slate-600 font-sans mt-0.5 break-words leading-relaxed font-normal">
                                            {reply.content}
                                          </p>
                                        </div>
                                      </div>

                                      {/* Delete action for reply */}
                                      {(reply.userId === currentUser.uid || isInstructor) && (
                                        <button
                                          onClick={() => setConfirmDelete({ id: reply.id, type: 'comment' })}
                                          className="text-slate-405 hover:text-red-500 p-1 rounded-md transition-colors hover:bg-red-50 shrink-0 cursor-pointer"
                                        >
                                          <Trash2 className="h-3 w-3" />
                                        </button>
                                      )}
                                    </div>
                                  ))}
                                </div>
                              )}

                              {/* Open Reply Sub-Form */}
                              {activeReplyId === comment.id && (
                                <div className="pl-6 sm:pl-8 ml-3.5 sm:ml-4">
                                  <div className="flex gap-2 bg-zinc-50/55 p-2 border border-zinc-200 rounded-lg">
                                    <input
                                      type="text"
                                      value={replyTextMap[comment.id] || ''}
                                      onChange={(e) => setReplyTextMap(prev => ({ ...prev, [comment.id]: e.target.value }))}
                                      placeholder={`ตอบกลับความคิดเห็นของ ${comment.userName}...`}
                                      className="flex-1 bg-white border border-gray-200 focus:border-blue-500 rounded-lg px-2.5 py-1.5 text-xs text-zinc-800 outline-none transition-all"
                                      maxLength={300}
                                    />
                                    <button
                                      onClick={() => handleAddReply(comment.id)}
                                      className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer whitespace-nowrap transition-colors"
                                    >
                                      ตอบกลับ
                                    </button>
                                  </div>
                                </div>
                              )}
                            </div>
                          );
                        })
                      )}
                    </div>
                  </div>
                </>
              ) : (
                <div className="text-center py-16 space-y-4">
                  <Play className="h-12 w-12 text-zinc-300 mx-auto fill-zinc-200" />
                  <p className="text-zinc-650 font-medium">ยินดีต้อนรับสู่ คอร์ส {course.title}</p>
                  <p className="text-zinc-400 text-xs max-w-sm mx-auto">
                    {isInstructor
                      ? 'คุณเป็นวิทยากรวิชานี้ เริ่มอัปโหลดวิดีโอและสื่อการเรียนสอนจากปุ่มบวกในสารบัญสารสนเทศทางซ้ายได้เลย!'
                      : 'ยังไม่มีห้องเรียนออนไลน์หรือวิชาเรียนว่างที่ครูจัดทำขึ้น โปรดรอคุณครูผู้สอนเพิ่มบทเรียนแรกเร็ว ๆ นี้'}
                  </p>
                </div>
              )}
            </div>
          )}

          {activeTab === 'materials' && (
            <div className="bg-white rounded-xl border border-gray-200 p-5 shadow-3xs text-left space-y-4">
              {!isActivated ? (
                /* LOCKED MATERIALS DISPLAY */
                <div className="p-4 sm:p-6 text-center space-y-4 max-w-sm mx-auto my-6">
                  <div className="h-16 w-16 bg-zinc-50 text-zinc-400 rounded-full flex items-center justify-center mx-auto border border-zinc-100 shadow-3xs">
                    <FileText className="h-6 w-6 text-zinc-400" />
                  </div>
                  <h3 className="font-sans font-medium text-sm text-zinc-800">
                    สื่อการเรียนและไฟล์แนบถูกล็อกอยู่
                  </h3>
                  <p className="text-xs text-zinc-500 px-4 font-sans leading-relaxed">
                    สื่อการเรียนรู้นี้สามารถเปิดให้ดาวน์โหลดได้เฉพาะผู้เรียนที่เปิดใช้งานรหัสลิขสิทธิ์ประจำคลาสนี้แล้วเท่านั้น กรุณาเปิดใช้งานร่วมกันที่เมนูบทเรียนท์เพื่อดาวน์โหลด
                  </p>
                  <button
                    onClick={() => setActiveTab('content')}
                    className="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-2 text-xs font-semibold cursor-pointer transition-colors shadow-3xs"
                  >
                    ไปป้อนรหัสคีย์เพื่อปลดล็อก
                  </button>
                </div>
              ) : (
                <>
                  <div className="flex justify-between items-center pb-2 border-b border-gray-100">
                    <h2 className="font-sans font-semibold text-sm text-zinc-700 flex items-center space-x-2.5">
                      <div className="h-7 w-7 rounded-lg bg-gradient-to-br from-[#B8E5FC] to-blue-50 flex items-center justify-center text-black border border-[#B8E5FC]/60 shadow-xs shrink-0">
                        <FileText className="h-4 w-4" strokeWidth={1.5} />
                      </div>
                      <span>คลังสื่อความรู้และเอกสารดาวน์โหลด ({materials.length})</span>
                    </h2>
                    {isInstructor && (
                      <button
                        onClick={() => setShowMaterialForm(true)}
                        className="flex items-center space-x-1.5 bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 rounded-lg text-xs font-semibold shadow-2xs transition-colors cursor-pointer"
                        id="btn-add-material"
                      >
                        <Plus className="h-4 w-4" />
                        <span>เพิ่มสื่อการเรียน</span>
                      </button>
                    )}
                  </div>

                  {materials.length === 0 ? (
                    <div className="py-12 text-center text-xs text-zinc-400">
                      วิชานี้ยังไม่มีคลังบทความหรือไฟล์แนบเสริมในระบบ
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {materials.map((mat) => (
                        <div
                          key={mat.id}
                          className="border border-gray-200 hover:border-blue-300 p-4 rounded-lg shadow-3xs hover:shadow-2xs transition-all text-left flex flex-col justify-between bg-white"
                        >
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] uppercase px-2 py-0.5 rounded font-mono bg-blue-50 text-blue-700 font-bold border border-blue-105 border-blue-100">
                            {mat.fileType}
                          </span>
                          {isInstructor && (
                            <button
                              onClick={() => setConfirmDelete({ id: mat.id, type: 'material' })}
                              className="text-zinc-400 hover:text-red-500 p-1 rounded hover:bg-red-50 cursor-pointer"
                              id={`delete-mat-${mat.id}`}
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          )}
                        </div>
                        <h4 className="text-sm font-semibold text-zinc-800 truncate" title={mat.title}>
                          {mat.title}
                        </h4>
                        <p className="text-xs text-zinc-500 line-clamp-2">
                          {mat.description || 'ไม่มีคำอธิบายเพิ่มเติม'}
                        </p>
                      </div>

                      <div className="pt-3 border-t border-gray-100 mt-3 flex items-center justify-between">
                        <span className="text-[10px] text-zinc-400 font-sans">
                          อัปโหลดเมื่อ: {formatThaiDate(mat.createdAt)}
                        </span>
                        <a
                          href={mat.fileUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="flex items-center space-x-1 text-xs text-blue-600 font-semibold hover:underline cursor-pointer"
                        >
                          <span>เปิดสื่อนี้</span>
                          <ExternalLink className="h-3 w-3" />
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
              )}
              </>
              )}
            </div>
          )}

          {activeTab === 'students' && (
            <div className="bg-white rounded-xl border border-gray-200 p-5 shadow-3xs text-left space-y-4">
              <h2 className="font-sans font-semibold text-sm text-zinc-700 flex items-center space-x-2.5 pb-2 border-b border-gray-100">
                <div className="h-7 w-7 rounded-lg bg-gradient-to-br from-[#B8E5FC] to-blue-50 flex items-center justify-center text-black border border-[#B8E5FC]/60 shadow-xs shrink-0">
                  <Users className="h-4 w-4" strokeWidth={1.5} />
                </div>
                <span>รายนามสมาชิกลงทะเบียนเรียนในคอร์ส ({enrollments.length} คน)</span>
              </h2>

              {enrollments.length === 0 ? (
                <div className="py-12 text-center text-xs text-zinc-400">
                  ยังไม่พบนิสิต นักเรียน เข้ามาตอบตกลงวิชาเรียนนี้
                </div>
              ) : (
                <div className="divide-y divide-gray-100 max-h-[450px] overflow-y-auto pr-1">
                  {enrollments.map((student) => (
                    <div key={student.id} className="py-3 flex items-center justify-between">
                      <div className="flex items-center space-x-2.5">
                        <div className="h-8 w-8 rounded-full bg-blue-550 bg-blue-50 border border-blue-105 border-blue-250 flex items-center justify-center font-semibold text-blue-655 text-blue-600 text-xs">
                          {student.userName?.substring(0, 2) || 'St'}
                        </div>
                        <div className="text-left">
                          <p className="text-xs font-semibold text-zinc-800">{student.userName}</p>
                          <p className="text-[10px] text-zinc-400 font-mono -mt-0.5">{student.userEmail}</p>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2">
                        <span className="text-[10px] text-zinc-500 bg-zinc-100 px-2.5 py-0.5 rounded flex items-center space-x-1">
                          <CheckCircle className="h-3.5 w-3.5 text-emerald-500" />
                          <span>นักเรียนชั้นเรียน</span>
                        </span>
                        {isInstructor && (
                          <button
                            onClick={() => setConfirmDelete({ id: student.id, type: 'student' })}
                            className="text-zinc-400 hover:text-red-500 p-1 rounded hover:bg-red-50 cursor-pointer"
                            title="ลบนักเรียน"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

        </div>
      </div>

      {/* Lesson Add Dialog Modal */}
      {showLessonForm && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-55 animate-fade-in" id="lesson-form-modal">
          <div className="bg-white rounded-2xl max-w-md w-full overflow-hidden border border-sky-100 shadow-2xl text-left">
            <div className="bg-gradient-to-r from-sky-450 to-blue-500 bg-sky-500 p-4 text-white flex justify-between items-center">
              <h3 className="font-sans font-bold text-sm">เพิ่มวิดีโอบทเรียนเรียนย่อย</h3>
              <button onClick={() => setShowLessonForm(false)} className="hover:bg-white/20 p-1 rounded-lg">✕</button>
            </div>
            
            <form onSubmit={handleAddLesson} className="p-5 space-y-4">
              <div className="space-y-1">
                <label className="text-2xs font-semibold text-slate-600 block">ชื่อบทเรียนย่อย *</label>
                <input
                  type="text"
                  value={lessonTitle}
                  onChange={(e) => setLessonTitle(e.target.value)}
                  placeholder="เช่น บทที่ 1: แนะนำพื้นฐานเบื้องต้น"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs outline-none focus:border-sky-400"
                  required
                />
              </div>

              {/* Source Mode Toggle (YouTube vs Secure Cloud Video) */}
              <div className="space-y-1.5">
                <label className="text-2xs font-semibold text-slate-600 block">ประเภทแหล่งที่มาของวิดีโอ *</label>
                <div className="grid grid-cols-2 gap-2 bg-slate-100 p-1 rounded-xl">
                  <button
                    type="button"
                    onClick={() => {
                      setVideoSourceType('youtube');
                      if (lessonVideoUrl.startsWith('s3://') || lessonVideoUrl.startsWith('supabase://') || lessonVideoUrl.includes('amazonaws') || lessonVideoUrl.includes('supabase')) {
                        setLessonVideoUrl('');
                      }
                    }}
                    className={`py-1.5 text-3xs font-bold rounded-lg transition-all cursor-pointer ${
                      videoSourceType === 'youtube'
                        ? 'bg-red-500 text-white shadow-3xs'
                        : 'text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    🚀 YouTube ลิงก์สาธารณะ
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setVideoSourceType('cloud');
                    }}
                    className={`py-1.5 text-3xs font-bold rounded-lg transition-all cursor-pointer ${
                      videoSourceType === 'cloud'
                        ? 'bg-indigo-600 text-white shadow-3xs'
                        : 'text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    🔒 Cloud (S3 หรือ Supabase) ส่วนตัว
                  </button>
                </div>
              </div>

              {/* Dynamic Inputs based on platform selection */}
              {videoSourceType === 'youtube' ? (
                <div className="space-y-1">
                  <label className="text-2xs font-semibold text-slate-600 block">ลิงก์วิดีโอ YouTube *</label>
                  <input
                    type="text"
                    value={lessonVideoUrl}
                    onChange={(e) => setLessonVideoUrl(e.target.value)}
                    placeholder="เช่น https://www.youtube.com/watch?v=..."
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs outline-none focus:border-sky-400"
                    required={videoSourceType === 'youtube'}
                  />
                  <span className="text-3xs text-slate-400 block mt-0.5">วางลิงก์ YouTube เพื่อให้ระบบสร้างกระดานวิดีโอมิติคลิกได้</span>
                </div>
              ) : (
                <div className="space-y-2">
                  <div className="space-y-1">
                    <label className="text-2xs font-semibold text-slate-600 block">ลิงก์วิดีโอ (S3 หรือ Supabase Storage) *</label>
                    <input
                      type="text"
                      value={lessonVideoUrl}
                      onChange={(e) => setLessonVideoUrl(e.target.value)}
                      placeholder="เช่น supabase://videos/vdo.mp4 หรือ s3://my-bucket/vdo.mp4"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono outline-none focus:border-sky-400"
                      required={videoSourceType === 'cloud'}
                    />
                  </div>

                  {/* S3/Supabase Configuration Credentials and status display */}
                  <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 space-y-2">
                    <h4 className="text-[10px] font-bold text-slate-700 flex items-center">
                      <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full mr-1.5 animate-pulse" />
                      สถานะระบบคลาวด์วิดีโอส่วนตัว
                    </h4>
                    
                    {cloudConfigStatus.loaded ? (
                      <div className="space-y-2 text-[9px] leading-relaxed text-slate-500">
                        {/* Supabase Status Indicators */}
                        <div className="border-b border-dashed border-slate-200 pb-1.5">
                          <span className="font-bold text-[10px] block text-slate-600 mb-0.5">⚡ Supabase Storage</span>
                          {cloudConfigStatus.SUPABASE_URL_STATUS && !cloudConfigStatus.SUPABASE_URL_STATUS.includes('Missing') ? (
                            <div className="text-emerald-600 font-medium flex items-center">
                              <span className="mr-1">🟢</span> พร้อมใช้งาน: {cloudConfigStatus.SUPABASE_URL_STATUS}
                            </div>
                          ) : (
                            <div className="text-amber-600 font-medium flex items-center">
                              <span className="mr-1">⚠️</span> ยังไม่ได้เปิดใช้งาน (ต้องการ <code className="bg-slate-100 px-1 py-0.2 rounded text-amber-800 font-mono">SUPABASE_URL</code> และ <code className="bg-slate-100 px-1 py-0.2 rounded text-amber-800 font-mono">SUPABASE_SERVICE_ROLE_KEY</code>)
                            </div>
                          )}
                        </div>

                        {/* S3 Status Indicators */}
                        <div>
                          <span className="font-bold text-[10px] block text-slate-600 mb-0.5">☁️ Amazon S3</span>
                          {cloudConfigStatus.AWS_ACCESS_KEY_ID_STATUS && !cloudConfigStatus.AWS_ACCESS_KEY_ID_STATUS.includes('Missing') ? (
                            <div className="text-emerald-600 font-medium">
                              <div className="flex items-center"><span className="mr-1">🟢</span> พร้อมใช้งาน (Bucket: {cloudConfigStatus.AWS_S3_BUCKET})</div>
                            </div>
                          ) : (
                            <div className="text-amber-600 font-medium flex items-center">
                              <span className="mr-1">⚠️</span> ยังไม่ได้เปิดใช้งาน (ต้องการ <code className="bg-slate-100 px-1 py-0.2 rounded text-amber-800 font-mono">AWS_ACCESS_KEY_ID</code>)
                            </div>
                          )}
                        </div>
                      </div>
                    ) : (
                      <div className="text-[10px] text-slate-500 animate-pulse">กำลังสแกนสถานะการเชื่อมต่อหลังบ้าน...</div>
                    )}
                  </div>

                  <div className="text-[9px] text-slate-500 bg-indigo-50 border border-indigo-100 rounded-lg p-2.5 space-y-1">
                    <span className="font-bold text-indigo-900 block">💡 วิธีระบุวิดีโอจาก Supabase Storage:</span>
                    <p className="text-indigo-850">
                      เมื่อสร้าง Storage Bucket แบบ <strong className="text-indigo-900">Private</strong> ใน Supabase เเล้ว และเติม Secrets แถบการตั้งค่า เรียบร้อยแล้ว สามารถวางลิงก์วิดีโอได้ 3 รูปแบบหลัก:
                    </p>
                    <ul className="list-disc list-inside space-y-1 text-indigo-850 font-mono text-[8px] pl-1">
                      <li><strong>รูปแบบสากล:</strong> <code className="bg-white/70 px-1 rounded">supabase://[ชื่อบักเก็ต]/[ชื่อไฟล์.mp4]</code></li>
                      <li><strong>รูปแบบคีย์:</strong> <code className="bg-white/70 px-1 rounded">[ชื่อบักเก็ต]/[ชื่อไฟล์.mp4]</code></li>
                      <li><strong>ลิงก์ Supabase Direct:</strong> <code className="bg-white/70 px-1 rounded">https://[project-id].supabase.co/storage/v1/object/public/[bucket]/[file]</code></li>
                    </ul>
                  </div>
                </div>
              )}

              <div className="space-y-1">
                <label className="text-2xs font-semibold text-slate-600 block">คำพูดสรุปแนะนำ / การบ้าน (เว้นว่างได้)</label>
                <textarea
                  value={lessonDesc}
                  onChange={(e) => setLessonDesc(e.target.value)}
                  placeholder="อธิบายสรุปเนื้อหาคร่าวๆ หรือแจกแจงแบบฝึกหัดในคลิปวิดีโอนี้..."
                  rows={3}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs outline-none focus:border-sky-400 resize-none"
                ></textarea>
              </div>

              <div className="flex justify-end space-x-2 pt-3 border-t">
                <button
                  type="button"
                  onClick={() => setShowLessonForm(false)}
                  className="px-3 py-1.5 hover:bg-slate-50 text-slate-500 rounded-lg text-2xs font-semibold"
                >
                  ยกเลิก
                </button>
                <button
                  type="submit"
                  className="bg-sky-500 hover:bg-sky-600 text-white px-4 py-1.5 rounded-lg text-2xs font-semibold shadow-xs"
                >
                  เพิ่มบทเรียน
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Material Add Dialog Modal */}
      {showMaterialForm && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-55 animate-fade-in" id="material-form-modal">
          <div className="bg-white rounded-2xl max-w-md w-full overflow-hidden border border-sky-100 shadow-2xl text-left">
            <div className="bg-sky-500 p-4 text-white flex justify-between items-center">
              <h3 className="font-sans font-bold text-sm">อัปโหลด / ลิงก์แนบสื่อการสอน</h3>
              <button onClick={() => setShowMaterialForm(false)} className="hover:bg-white/20 p-1 rounded-lg">✕</button>
            </div>

            <form onSubmit={handleAddMaterial} className="p-5 space-y-4">
              <div className="space-y-1">
                <label className="text-2xs font-semibold text-slate-600 block">หัวเอกสาร / ชื่อสื่อประกอบเรียน *</label>
                <input
                  type="text"
                  value={materialTitle}
                  onChange={(e) => setMaterialTitle(e.target.value)}
                  placeholder="เช่น สไลด์สรุปบทเรียน, ลิงก์ดาวน์โหลดแนวข้อสอบ"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs outline-none focus:border-sky-400"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-2xs font-semibold text-slate-600 block">หมวดหมู่ลักษณะไฟล์</label>
                  <select
                    value={materialType}
                    onChange={(e) => setMaterialType(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs outline-none focus:border-sky-400"
                  >
                    <option value="pdf">PDF Document</option>
                    <option value="doc">Word / Text Doc</option>
                    <option value="slide">Google Slides / Keynote</option>
                    <option value="link">Website Links</option>
                    <option value="archive">Zip / Archive</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-2xs font-semibold text-slate-600 block">ผูกกับวิดีโอบทที่</label>
                  <select
                    value={selectedLesson?.id || ''}
                    disabled={true} // bound to the active view to make it straightforward
                    className="w-full bg-slate-100 border border-slate-200 rounded-xl px-3 py-2 text-xs outline-none opacity-80"
                  >
                    <option value={selectedLesson?.id}>{selectedLesson?.title || 'บทเรียนหลัก'}</option>
                  </select>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-2xs font-semibold text-slate-600 block">วิธีการแนบไฟล์สื่อการสอน</label>
                <div className="flex bg-zinc-100 p-1 rounded-lg">
                  <button
                    type="button"
                    onClick={() => { setUploadMethod('file'); setMaterialUrl(''); setSelectedFileName(''); setFileReadStatus(null); }}
                    className={`flex-1 py-1 text-center rounded text-2xs font-bold transition-all ${uploadMethod === 'file' ? 'bg-white shadow-3xs text-blue-600' : 'text-zinc-500'}`}
                  >
                    อัปโหลดไฟล์จากเครื่อง
                  </button>
                  <button
                    type="button"
                    onClick={() => { setUploadMethod('link'); setMaterialUrl(''); setSelectedFileName(''); setFileReadStatus(null); }}
                    className={`flex-1 py-1 text-center rounded text-2xs font-bold transition-all ${uploadMethod === 'link' ? 'bg-white shadow-3xs text-blue-600' : 'text-zinc-500'}`}
                  >
                    ระบุลิงก์ภายนอก
                  </button>
                </div>
              </div>

              {uploadMethod === 'file' ? (
                <div className="space-y-1.5">
                  <label className="text-2xs font-semibold text-slate-600 block">อัปโหลดไฟล์สื่อ (ไม่เกิน 1MB) *</label>
                  <div className="border-2 border-dashed border-gray-300 hover:border-blue-400 rounded-xl p-4 text-center cursor-pointer relative bg-zinc-50 hover:bg-zinc-100/70 transition-all">
                    <input
                      type="file"
                      onChange={handleLocalFileSelect}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                      required={!materialUrl}
                    />
                    <div className="space-y-1">
                      <Paperclip className="h-5 w-5 text-zinc-400 mx-auto" />
                      <p className="text-2xs font-bold text-zinc-700">
                        {selectedFileName || 'คลิกเพื่อเลือกไฟล์ประกอบย่อย'}
                      </p>
                      <p className="text-3xs text-zinc-400">รองรับ PDF, Word, รูปภาพ, สไลด์, และ Zip</p>
                    </div>
                  </div>
                  {fileReadStatus && (
                    <p className={`text-3xs font-semibold ${fileReadStatus.includes('สำเร็จ') ? 'text-emerald-600' : 'text-zinc-500'}`}>
                      {fileReadStatus}
                    </p>
                  )}
                </div>
              ) : (
                <div className="space-y-1">
                  <label className="text-2xs font-semibold text-slate-600 block">ลิงก์แนบไฟล์สื่อดาวน์โหลด (Google Drive / DropBox / URL) *</label>
                  <input
                    type="url"
                    value={materialUrl}
                    onChange={(e) => setMaterialUrl(e.target.value)}
                    placeholder="เช่น https://drive.google.com/..."
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs outline-none focus:border-sky-400"
                    required={uploadMethod === 'link'}
                  />
                </div>
              )}

              <div className="space-y-1">
                <label className="text-2xs font-semibold text-slate-600 block">รายละเอียดไฟล์คร่าวๆ (อธิบายเพิ่มเติม)</label>
                <textarea
                  value={materialDesc}
                  onChange={(e) => setMaterialDesc(e.target.value)}
                  placeholder="เพิ่มรายละเอียดเกี่ยวกับการนำเอกสารนี้ไปประยุกต์ใช้งาน..."
                  rows={2}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs outline-none focus:border-sky-400 resize-none"
                ></textarea>
              </div>

              <div className="flex justify-end space-x-2 pt-3 border-t">
                <button
                  type="button"
                  onClick={() => setShowMaterialForm(false)}
                  className="px-3 py-1.5 hover:bg-slate-50 text-slate-500 rounded-lg text-2xs font-semibold"
                >
                  ยกเลิก
                </button>
                <button
                  type="submit"
                  className="bg-sky-500 hover:bg-sky-600 text-white px-4 py-1.5 rounded-lg text-2xs font-semibold shadow-xs"
                >
                  เพิ่มเอกสารประกอบ
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {confirmDelete && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-white rounded-xl shadow-lg border border-gray-100 max-w-sm w-full p-6 animate-in fade-in zoom-in duration-200">
            <h3 className="text-lg font-bold text-gray-900 mb-2">ยืนยันการลบ</h3>
            <p className="text-sm text-gray-500 mb-6">คุณแน่ใจหรือไม่ที่จะลบรายการนี้? การกระทำนี้ไม่สามารถย้อนกลับได้</p>
            <div className="flex items-center justify-end space-x-3">
              <button
                onClick={() => setConfirmDelete(null)}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                style={{ backgroundColor: '#ffffff', color: '#000000', border: '1.5px solid #000000', borderRadius: '8px' }}
              >
                ยกเลิก
              </button>
              <button
                onClick={() => {
                  if (confirmDelete.type === 'lesson') handleDeleteLesson(confirmDelete.id);
                  if (confirmDelete.type === 'material') handleDeleteMaterial(confirmDelete.id);
                  if (confirmDelete.type === 'comment') handleDeleteComment(confirmDelete.id);
                  if (confirmDelete.type === 'student') handleDeleteStudent(confirmDelete.id);
                }}
                className="px-4 py-2 text-sm font-medium transition-colors shadow-sm"
                style={{ backgroundColor: '#ef4444', color: '#ffffff', border: '1.5px solid #000000', borderRadius: '8px' }}
              >
                ยืนยันการลบ
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
