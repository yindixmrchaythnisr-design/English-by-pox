import React, { useState } from 'react';
import { BANNER_COLORS } from '../utils';
import { BookOpen, FolderPlus, HelpCircle, X } from 'lucide-react';

interface CourseFormProps {
  onSubmit: (title: string, description: string, bannerColor: string, enrollmentCode?: string) => Promise<void>;
  onClose: () => void;
}

export default function CourseForm({ onSubmit, onClose }: CourseFormProps) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [enrollmentCode, setEnrollmentCode] = useState('');
  const [bannerColor, setBannerColor] = useState(BANNER_COLORS[0]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim()) {
      setError('กรุณากรอกข้อมูลให้ครบถ้วนทุกช่อง');
      return;
    }
    
    try {
      setIsSubmitting(true);
      setError('');
      await onSubmit(title, description, bannerColor, enrollmentCode.trim() || undefined);
      setTitle('');
      setDescription('');
      setEnrollmentCode('');
    } catch (err: any) {
      setError(err.message || 'เกิดข้อผิดพลาดในการสร้างห้องเรียน');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-55 animate-fade-in" id="course-form-modal">
      <div className="bg-white rounded-2xl max-w-lg w-full overflow-hidden border border-sky-100 shadow-2xl flex flex-col">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-sky-400 to-blue-500 p-5 flex justify-between items-center text-white">
          <div className="flex items-center space-x-2">
            <FolderPlus className="h-5 w-5" />
            <h2 className="font-sans font-bold text-base">สร้างห้องเรียนใหม่ (Create Course)</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 hover:bg-white/20 rounded-lg transition-colors text-white"
            id="btn-close-form"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5 flex-1">
          {error && (
            <div className="bg-red-50 text-red-600 p-3 rounded-xl border border-red-100 text-xs font-medium">
              {error}
            </div>
          )}

          {/* Title input */}
          <div className="space-y-1.5 text-left">
            <label className="text-xs font-semibold text-slate-700 block">
              ชื่อหัวข้อ / วิชาเรียน <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => { setTitle(e.target.value); if(error) setError(''); }}
              placeholder="เช่น พื้นฐานการพัฒนาเว็บด้วย React, ภาษาไทยเพื่อการสื่อสาร"
              className="w-full bg-slate-50 border border-slate-200 focus:border-sky-400 focus:bg-white rounded-xl px-4 py-3 text-xs text-slate-800 outline-none transition-all placeholder:text-slate-400"
              maxLength={150}
              required
            />
          </div>

          {/* Enrollment Code input */}
          <div className="space-y-1.5 text-left">
            <label className="text-xs font-semibold text-slate-700 block">
              รหัสเข้ารหัสห้องเรียน (Enrollment Code) - Optional
            </label>
            <input
              type="text"
              value={enrollmentCode}
              onChange={(e) => { setEnrollmentCode(e.target.value); if(error) setError(''); }}
              placeholder="ตั้งรหัสลับสำหรับให้นักเรียนกรอกเพื่อเข้าเรียน"
              className="w-full bg-slate-50 border border-slate-200 focus:border-sky-400 focus:bg-white rounded-xl px-4 py-3 text-xs text-slate-800 outline-none transition-all placeholder:text-slate-400"
              maxLength={20}
            />
          </div>

          {/* Description input */}
          <div className="space-y-1.5 text-left">
            <label className="text-xs font-semibold text-slate-700 block">
              รายละเอียดวิชา / คำอธิบาย <span className="text-red-500">*</span>
            </label>
            <textarea
              value={description}
              onChange={(e) => { setDescription(e.target.value); if(error) setError(''); }}
              placeholder="อธิบายเนื้อหาโดยรวม สิ่งที่นักเรียนจะได้รับจากห้องเรียนนี้..."
              rows={4}
              className="w-full bg-slate-50 border border-slate-200 focus:border-sky-400 focus:bg-white rounded-xl px-4 py-3 text-xs text-slate-800 outline-none transition-all resize-none placeholder:text-slate-400"
              maxLength={1000}
              required
            ></textarea>
          </div>

          {/* Color theme selection */}
          <div className="space-y-2 text-left">
            <label className="text-xs font-semibold text-slate-700 block">
              เลือกโทนสีหัวคอร์ส (Banner Theme Color)
            </label>
            <div className="flex flex-wrap gap-2.5">
              {BANNER_COLORS.map((bgGradient, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setBannerColor(bgGradient)}
                  className={`h-9 w-18 rounded-lg bg-gradient-to-tr ${bgGradient} border-2 transition-all relative overflow-hidden`}
                  style={{
                    borderColor: bannerColor === bgGradient ? '#0ea5e9' : 'transparent',
                    boxShadow: bannerColor === bgGradient ? '0 0 10px rgba(14, 165, 233, 0.4)' : 'none'
                  }}
                  id={`color-picker-${idx}`}
                >
                  {bannerColor === bgGradient && (
                    <span className="absolute inset-0 flex items-center justify-center text-white font-bold text-xs bg-black/10">
                      ✓
                    </span>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-4 border-t border-sky-50 flex justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 hover:bg-slate-50 text-slate-500 rounded-xl text-xs font-semibold transition-colors"
              id="btn-cancel-course"
            >
              ยกเลิก
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="bg-gradient-to-r from-sky-400 to-blue-500 hover:from-sky-500 hover:to-blue-600 text-white px-5 py-2 rounded-xl text-xs font-semibold shadow-md shadow-sky-100 transition-all disabled:opacity-50"
              id="btn-submit-course"
            >
              {isSubmitting ? 'กำลังสร้างคอร์ส...' : 'สร้างคอร์สเรียน'}
            </button>
          </div>

        </form>

      </div>
    </div>
  );
}
