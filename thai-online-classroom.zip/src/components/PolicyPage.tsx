import React from 'react';
import { motion } from 'motion/react';

interface PolicyPageProps {
  onAgree: () => void;
}

export default function PolicyPage({ onAgree }: PolicyPageProps) {
  return (
    <div className="min-h-screen bg-gradient-to-r from-[#B8E5FC] via-white to-[#B8E5FC] flex flex-col items-center justify-center p-4 py-12">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.4 }}
        className="max-w-xl w-full bg-white rounded-2xl shadow-xl overflow-hidden flex flex-col border border-gray-200 max-h-[85vh]"
      >
        <div className="bg-gradient-to-r from-[#B8E5FC] via-white to-[#B8E5FC] p-5 flex items-center justify-center shrink-0 border-b border-[#B8E5FC]/50">
          <h1 className="text-base sm:text-lg font-bold text-black tracking-tight text-center">ข้อตกลงและเงื่อนไขการใช้งาน</h1>
        </div>
        
        <div className="p-6 sm:p-8 overflow-y-auto flex-1 space-y-6 text-xs text-black leading-relaxed bg-white">
          <section>
            <h2 className="text-sm font-bold text-black mb-1.5">
              1. การยอมรับข้อตกลง
            </h2>
            <p className="text-zinc-900">
              การเข้าใช้งานเว็บไซต์ English By Pox ถือว่าผู้ใช้งานตกลงและยอมรับข้อกำหนด เงื่อนไข และนโยบายความเป็นส่วนตัวนี้ หากท่านไม่เห็นด้วยกับข้อกำหนดใดๆ โปรดงดการเข้าใช้งานระบบนี้
            </p>
          </section>

          <section>
            <h2 className="text-sm font-bold text-black mb-1.5">
              2. การใช้งานข้อมูลส่วนบุคคล
            </h2>
            <p className="text-zinc-900">
              ระบบจำเป็นต้องขอเข้าถึงข้อมูลโปรไฟล์เบื้องต้นผ่าน Google Account (เช่น ชื่อ, อีเมล, รูปโปรไฟล์) เพื่อระบุตัวตนในการเข้าชั้นเรียน การจัดการสิทธิ์ผู้ใช้งาน และการส่งการแจ้งเตือนต่างๆ ข้อมูลของท่านจะถูกเก็บรักษาอย่างปลอดภัยและไม่ถูกนำไปเผยแพร่หรือแสวงหาผลกำไรใดๆ โดยไม่ได้รับอนุญาต
            </p>
          </section>

          <section>
            <h2 className="text-sm font-bold text-black mb-1.5">
              3. สิทธิในความรับผิดชอบและการใช้งาน
            </h2>
            <p className="text-zinc-900">
              สื่อการสอน วอยซ์คลิป วิดีโอ และเอกสารต่าง ๆ ที่ปรากฏอยู่ในระบบนี้เป็นลิขสิทธิ์ของครูผู้จัดทำ หรือนำมาอ้างอิงเพื่อการเรียนการสอนเท่านั้น ไม่อนุญาตให้ผู้ใดคัดลอก หรือนำไปใช้ในเชิงพาณิชย์เด็ดขาด ผู้ใช้งานต้องรับผิดชอบต่อพฤติกรรมการพิมพ์ความคิดเห็นหรืออัปโหลดข้อมูลใดๆ ในห้องเรียน ไม่ให้ผิดต่อกฎหมาย หรือสร้างความเดือดร้อนแก่ผู้อื่น
            </p>
          </section>
          
          <section>
            <h2 className="text-sm font-bold text-black mb-1.5">
              4. นโยบายการบันทึกภาพ เสียง หรือเอกสาร
            </h2>
            <p className="text-zinc-900">
              ห้ามมิให้ผู้เรียนบันทึกเสียง บันทึกวิดีโอ หรือแคปหน้าจอสาระสำคัญ เนื้อหา ข้อมูลส่วนตัวของเพื่อนร่วมชั้น หรือเอกสารประกอบการสอนใดๆ ภายในห้องเรียนนี้โดยไม่ได้รับอนุญาตเป็นลายลักษณ์อักษรจากครูผู้สอน การละเมิดข้อตกลงนี้จะนำไปสู่การระงับบัญชีผู้ใช้งานทันที
            </p>
          </section>

          <section>
            <h2 className="text-sm font-bold text-black mb-1.5">
              5. การระงับการให้บริการ
            </h2>
            <p className="text-zinc-900">
               ผู้จัดทำระบบขอสงวนสิทธิ์ในการระงับบัญชีผู้ใช้งาน หรือลบข้อมูลใดๆ หากพบว่ามีการกระทำที่ขัดต่อข้อกำหนด กฎหมาย หรือสร้างความเดือดร้อนให้กับส่วนรวม โดยไม่ต้องแจ้งให้ทราบล่วงหน้า
            </p>
          </section>
        </div>

        <div className="p-5 bg-zinc-50 border-t border-gray-200 flex flex-col sm:flex-row items-center justify-between gap-4 shrink-0">
          <div className="text-[10px] text-zinc-600 max-w-xs">
            โดยการคลิก <strong>"ฉันยอมรับข้อตกลง"</strong> คุณยืนยันว่าคุณได้อ่านและทำความเข้าใจข้อกำหนดทั้งหมดและพร้อมที่จะปฏิบัติตาม
          </div>
          <button
            onClick={onAgree}
            className="w-full sm:w-auto flex items-center justify-center bg-black hover:bg-zinc-800 text-white px-6 py-2.5 rounded-lg font-bold shadow-sm transition-colors cursor-pointer text-xs"
          >
            ฉันยอมรับข้อตกลงและเงื่อนไข
          </button>
        </div>
      </motion.div>
    </div>
  );
}
