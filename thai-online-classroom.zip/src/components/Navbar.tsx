import React from 'react';
import { auth } from '../firebase';
import { GoogleAuthProvider, signInWithPopup, signOut } from 'firebase/auth';
import { BookOpen, LogOut, LogIn, RefreshCw, GraduationCap, Menu, Bell, MessageSquare } from 'lucide-react';
import { UserProfile } from '../types';
import mascotLogo from '../assets/images/regenerated_image_1781014822914.png';

interface NavbarProps {
  user: UserProfile | null;
  onRoleToggle: () => void;
  isLoading: boolean;
  onHome?: () => void;
  onMenuClick?: () => void;
  unreadNotificationsCount?: number;
  onNotificationsClick?: () => void;
  onDMClick?: () => void;
}

export default function Navbar({
  user,
  onRoleToggle,
  isLoading,
  onHome,
  onMenuClick,
  unreadNotificationsCount = 0,
  onNotificationsClick,
  onDMClick
}: NavbarProps) {
  const handleLogin = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (error) {
      console.error("Authentication Error: ", error);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error("Sign Out Error: ", error);
    }
  };

  return (
    <nav className="bg-white border-b border-gray-200 sticky top-0 z-50" id="lms-navbar">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          
          {/* Logo Section */}
          <div className="flex items-center space-x-3">
            {/* Hamburger button (Standard Google style) */}
            <button 
              onClick={onMenuClick}
              className="p-2 hover:bg-gray-100 rounded-full text-zinc-600 transition-colors"
              title="เมนูนำทาง"
              id="btn-navbar-menu"
            >
              <Menu className="h-5 w-5" />
            </button>

            {/* Mascot & Brand */}
            <div 
              onClick={onHome}
              className={`flex items-center space-x-2.5 ${onHome ? 'cursor-pointer hover:opacity-90' : ''}`}
            >
              <img 
                src={mascotLogo} 
                alt="English By Pox Mascot" 
                referrerPolicy="no-referrer"
                className="h-10 w-10 sm:h-11 sm:w-11 object-contain rounded-lg border border-slate-100 shadow-3xs"
              />
              <div className="text-left">
                <span className="font-sans font-medium text-lg sm:text-xl text-zinc-700 block tracking-tight">
                  English By Pox
                </span>
                <span className="text-[10px] text-zinc-500 block -mt-1 font-medium bg-zinc-100 leading-tight px-1.5 py-0.5 rounded">
                  ห้องเรียนออนไลน์คุณภาพ
                </span>
              </div>
            </div>
          </div>

          {/* Actions & Profiles */}
          <div className="flex items-center space-x-4">
            {isLoading ? (
              <div className="flex items-center space-x-2 text-xs text-blue-500 font-sans">
                <RefreshCw className="h-4 w-4 animate-spin" />
                <span>กำลังโหลด...</span>
              </div>
            ) : user ? (
              <div className="flex items-center space-x-2 sm:space-x-3.5">
                
                {/* DM Chat Button */}
                <button
                  onClick={onDMClick}
                  className="p-1.5 text-zinc-500 hover:text-blue-600 hover:bg-zinc-50 rounded-full transition-all relative cursor-pointer"
                  title="กล่องข้อความบรรยายส่วนตัว"
                  id="btn-navbar-dm"
                >
                  <MessageSquare className="h-4.5 w-4.5" />
                </button>

                {/* Notifications Bell Button */}
                <button
                  onClick={onNotificationsClick}
                  className="p-1.5 text-zinc-500 hover:text-blue-600 hover:bg-zinc-50 rounded-full transition-all relative cursor-pointer"
                  title="การแจ้งเตือน"
                  id="btn-navbar-notifs"
                >
                  <Bell className="h-4.5 w-4.5" />
                  {unreadNotificationsCount > 0 && (
                    <span className="absolute top-1 right-1 h-4 w-4 bg-red-500 text-[9px] text-white font-extrabold flex items-center justify-center rounded-full animate-bounce">
                      {unreadNotificationsCount}
                    </span>
                  )}
                </button>

                {/* Role Switcher */}
                <div className="hidden md:flex bg-blue-50/70 p-1.5 rounded-lg border border-blue-100 items-center">
                  <span className="text-xs text-zinc-600 px-2 font-sans font-medium">
                    สถานะของคุณ: <span className="text-blue-600 font-bold">{user.role === 'instructor' ? 'ผู้สอน' : 'นักเรียน'}</span>
                  </span>
                  <button
                    onClick={onRoleToggle}
                    className="flex items-center space-x-1.5 bg-white hover:bg-blue-50 text-blue-600 hover:text-blue-700 px-2.5 py-1 rounded-md text-xs font-semibold shadow-3xs border border-blue-200 transition-all duration-200"
                    id="btn-toggle-role"
                  >
                    <RefreshCw className="h-3 w-3" />
                    <span>สลับบทบาท</span>
                  </button>
                </div>

                {/* Mobile version of role indicator */}
                <button
                  onClick={onRoleToggle}
                  className="md:hidden flex items-center space-x-1 bg-blue-50 hover:bg-blue-100 text-blue-600 px-2.5 py-1.5 rounded-lg text-xs font-semibold border border-blue-100 transition-all"
                  id="btn-toggle-role-mobile"
                  title="สลับบทบาท"
                >
                  <span className="font-bold">สลับ</span>
                </button>

                {/* User Info Avatar */}
                <div className="flex items-center space-x-2.5 pl-2 border-l border-gray-200">
                  <img
                    referrerPolicy="no-referrer"
                    src={user.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=80&q=80'}
                    alt={user.name}
                    className="h-8 w-8 rounded-full border border-gray-200 object-cover"
                  />
                  <div className="hidden sm:block text-left">
                    <p className="text-xs font-semibold text-zinc-700 max-w-[120px] truncate">{user.name}</p>
                    <p className="text-[10px] text-zinc-400 truncate max-w-[120px] -mt-0.5">{user.email}</p>
                  </div>
                </div>

                {/* Sign-out button */}
                <button
                  onClick={handleLogout}
                  className="p-2 text-zinc-400 hover:text-red-500 hover:bg-red-50 rounded-full transition-all duration-200"
                  id="btn-signout"
                  title="ออกจากระบบ"
                >
                  <LogOut className="h-4.5 w-4.5" />
                </button>
              </div>
            ) : (
              <button
                onClick={handleLogin}
                className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-xs sm:text-sm font-semibold shadow-xs transition-colors duration-200"
                id="btn-login"
              >
                <LogIn className="h-4 w-4" />
                <span>เข้าสู่ระบบด้วย Google</span>
              </button>
            )}
          </div>

        </div>
      </div>
    </nav>
  );
}
