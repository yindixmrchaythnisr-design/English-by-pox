import React, { useState, useEffect, useRef } from 'react';
import { auth, db, handleFirestoreError, OperationType } from './firebase';
import { onAuthStateChanged, GoogleAuthProvider, signInWithPopup } from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  onSnapshot,
  query,
  orderBy,
  where,
  addDoc,
  runTransaction,
  deleteField,
  deleteDoc
} from 'firebase/firestore';
import {
  GraduationCap,
  BookOpen,
  Search,
  Plus,
  Filter,
  Users,
  LogOut,
  Calendar,
  Layers,
  Sparkles,
  Info,
  ExternalLink,
  ShieldCheck,
  CheckCircle2,
  Video,
  Pencil,
  Check,
  X,
  AlertTriangle,
  RefreshCw,
  MoreHorizontal,
  Edit2,
  Trash2
} from 'lucide-react';
import Navbar from './components/Navbar';
import CourseCard from './components/CourseCard';
import CourseForm from './components/CourseForm';
import CourseDetail from './components/CourseDetail';
import PolicyPage from './components/PolicyPage';
import { Course, UserProfile, Enrollment, Notification, DMMessage } from './types';
import { BANNER_COLORS } from './utils';
import mascotLogo from './assets/images/regenerated_image_1781014822914.png';

// Import Motion safely
import { motion, AnimatePresence } from 'motion/react';
import { checkSafety } from './lib/safetyModeration';

export default function App() {
  // Policy agreement state
  const [hasAgreedToPolicy, setHasAgreedToPolicy] = useState(() => localStorage.getItem('agreedToPolicy') === 'true');

  // App loading and user states
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [firebaseUser, setFirebaseUser] = useState<any>(null);
  const [isLoadingAuth, setIsLoadingAuth] = useState(true);
  const [isLoadingData, setIsLoadingData] = useState(false);

  // Edit Name & Role Switch restriction States
  const [isEditingName, setIsEditingName] = useState(false);
  const [newName, setNewName] = useState('');
  const [drawerNewName, setDrawerNewName] = useState('');
  const [isEditingNameInDrawer, setIsEditingNameInDrawer] = useState(false);
  const [isUpdatingName, setIsUpdatingName] = useState(false);
  const [roleToggleError, setRoleToggleError] = useState<string | null>(null);

  // Classroom data lists
  const [courses, setCourses] = useState<Course[]>([]);
  const [userEnrollments, setUserEnrollments] = useState<Enrollment[]>([]);
  
  // Dashboard filtration states
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<'all' | 'enrolled' | 'my-created'>('all');

  // Interactive navigation routing state
  const [activeCourse, setActiveCourse] = useState<Course | null>(null);
  
  // Modals state
  const [showAddCourseModal, setShowAddCourseModal] = useState(false);
  const [enrollingCourseId, setEnrollingCourseId] = useState<string | null>(null);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  // Notifications & DM Messaging States
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isDMOpen, setIsDMOpen] = useState(false);
  const [dmMessages, setDmMessages] = useState<DMMessage[]>([]);
  const [dmRecipientId, setDmRecipientId] = useState<string | null>(null);
  const [dmRecipientName, setDmRecipientName] = useState('');
  const [dmText, setDmText] = useState('');
  const [allStudents, setAllStudents] = useState<UserProfile[]>([]);
  const [allInstructors, setAllInstructors] = useState<UserProfile[]>([]);
  const [editingMessageId, setEditingMessageId] = useState<string | null>(null);
  const [activeMessageId, setActiveMessageId] = useState<string | null>(null);
  const [heldMessageId, setHeldMessageId] = useState<string | null>(null);
  const longPressTimerRef = useRef<NodeJS.Timeout | null>(null);

  const handleHoldStart = (messageId: string) => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
    }
    longPressTimerRef.current = setTimeout(() => {
      setHeldMessageId(messageId);
    }, 600);
  };

  const handleHoldEnd = () => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
  };
  const [activeTabDM, setActiveTabDM] = useState<'chats' | 'new-chat'>('chats');
  const [dmRoomsList, setDmRoomsList] = useState<{ userId: string; name: string; photoURL: string; lastMessage?: string; unread?: boolean }[]>([]);

  // 1. Auth and User Profile Synchronization
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setIsLoadingAuth(true);
      try {
        if (user) {
          setFirebaseUser(user);
          // Fetch or initialize user profile document
          const userDocRef = doc(db, 'users', user.uid);
          let userDoc;
          try {
            userDoc = await getDoc(userDocRef);
          } catch (err) {
            console.error("Error fetching user profile, will retry implicitly:", err);
            // Don't bomb on initial load error due to connection
          }

          if (userDoc && userDoc.exists()) {
            setCurrentUser(userDoc.data() as UserProfile);
          } else if (userDoc) {
            const initialProfile: UserProfile = {
              uid: user.uid,
              name: user.displayName || 'ผู้เรียนผู้สอนนิรนาม',
              email: user.email || '',
              photoURL: user.photoURL || '',
              role: 'student', // default role
              createdAt: new Date().toISOString()
            };
            try {
              await setDoc(userDocRef, initialProfile);
              setCurrentUser(initialProfile);
            } catch (err) {
              console.error("Error creating user profile:", err);
            }
          }
        } else {
          setFirebaseUser(null);
          setCurrentUser(null);
        }
      } catch (err) {
        console.error("Auth database sync failed: ", err);
      } finally {
        setIsLoadingAuth(false);
      }
    });

    return () => unsubscribe();
  }, []);

  // Fetch all instructors and students
  useEffect(() => {
    const fetchUsers = async () => {
      const q = query(collection(db, 'users'));
      const snapshot = await getDocs(q);
      const allUsers = snapshot.docs.map(doc => doc.data() as UserProfile).filter(u => u.uid !== currentUser?.uid);
      setAllInstructors(allUsers.filter(u => u.role === 'instructor'));
      setAllStudents(allUsers.filter(u => u.role === 'student'));
    };
    if (currentUser) fetchUsers();
  }, [currentUser]);

  // 2. Real-time Subscription to Public Course Directory
  useEffect(() => {
    if (!currentUser) return;

    setIsLoadingData(true);
    const coursesQuery = query(collection(db, 'courses'), orderBy('createdAt', 'desc'));
    
    const unsubscribe = onSnapshot(coursesQuery, (snapshot) => {
      const fetchedCourses: Course[] = [];
      snapshot.forEach((doc) => {
        fetchedCourses.push({ ...doc.data() as Course, id: doc.id });
      });
      setCourses(fetchedCourses);
      setIsLoadingData(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'courses');
      setIsLoadingData(false);
    });

    return () => unsubscribe();
  }, [currentUser]);

  // 3. Real-time Subscription to My Course Registration/Enrollments
  useEffect(() => {
    if (!currentUser) return;

    const enrollmentsQuery = query(
      collection(db, 'enrollments'),
      where('userId', '==', currentUser.uid)
    );

    const unsubscribe = onSnapshot(enrollmentsQuery, (snapshot) => {
      const fetchedEnrollments: Enrollment[] = [];
      snapshot.forEach((doc) => {
        fetchedEnrollments.push({ ...doc.data() as Enrollment });
      });
      setUserEnrollments(fetchedEnrollments);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'enrollments');
    });

    return () => unsubscribe();
  }, [currentUser]);

  // 4. Real-time Subscription to Notifications
  useEffect(() => {
    if (!currentUser) return;

    const nQuery = query(
      collection(db, 'notifications'),
      where('recipientId', '==', currentUser.uid)
    );

    const unsubscribe = onSnapshot(nQuery, (snapshot) => {
      const fetched: Notification[] = [];
      snapshot.forEach((doc) => fetched.push({ ...doc.data() as Notification }));
      fetched.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      setNotifications(fetched);
    }, (err) => console.error("Notif subscription error:", err));

    return () => unsubscribe();
  }, [currentUser]);

  // 5. Subscription to DM Messages
  useEffect(() => {
    if (!currentUser) return;
    
    // Subscription to DM Messages (Server-side-filtered)
    // Fetch both sent and received messages and merge them client-side
    const senderQuery = query(collection(db, 'dm_messages'), where('senderId', '==', currentUser.uid));
    const recipientQuery = query(collection(db, 'dm_messages'), where('recipientId', '==', currentUser.uid));

    let senderMsgs: DMMessage[] = [];
    let recipientMsgs: DMMessage[] = [];

    const updateCombined = () => {
      setDmMessages([...senderMsgs, ...recipientMsgs]);
    };

    const unsubscribeSender = onSnapshot(senderQuery, (snapshot) => {
      senderMsgs = snapshot.docs.map(doc => doc.data() as DMMessage);
      updateCombined();
    }, (err) => console.error("DM sender subscription error:", err));
    
    const unsubscribeRecipient = onSnapshot(recipientQuery, (snapshot) => {
      recipientMsgs = snapshot.docs.map(doc => doc.data() as DMMessage);
      updateCombined();
    }, (err) => console.error("DM recipient subscription error:", err));

    return () => {
      unsubscribeSender();
      unsubscribeRecipient();
    };
  }, [currentUser]);

  // Presence Effect
  useEffect(() => {
    if (!currentUser) return;
    const userRef = doc(db, 'users', currentUser.uid);
    const updateStatus = (status: 'online' | 'offline') => {
      updateDoc(userRef, { status, lastSeen: new Date().toISOString() });
    };

    const handleVisibilityChange = () => {
      updateStatus(document.visibilityState === 'visible' ? 'online' : 'offline');
    };
    
    // Init
    updateStatus('online');
    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      updateStatus('offline');
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [currentUser]);

  // Mark as Read Effect
  useEffect(() => {
    if (!currentUser || !dmRecipientId || !isDMOpen) return;
    
    const unreadMessages = dmMessages.filter(m => 
      m.senderId === dmRecipientId && 
      m.recipientId === currentUser.uid && 
      !m.isRead
    );

    unreadMessages.forEach(msg => {
      updateDoc(doc(db, 'dm_messages', msg.id), { isRead: true });
    });
  }, [dmMessages, dmRecipientId, isDMOpen, currentUser]);

  // Role toggle: instructor vs student (Enforcing a limit of strictly one teacher)
  const handleRoleToggle = async () => {
    if (!currentUser) return;
    setRoleToggleError(null);
    const nextRole = currentUser.role === 'student' ? 'instructor' : 'student';
    
    if (nextRole === 'instructor') {
      try {
        const q = query(collection(db, 'users'), where('role', '==', 'instructor'));
        const querySnapshot = await getDocs(q);
        let existsOther = false;
        let otherName = '';
        let otherEmail = '';
        
        querySnapshot.forEach((doc) => {
          const u = doc.data() as UserProfile;
          if (u.uid !== currentUser.uid) {
            existsOther = true;
            otherName = u.name;
            otherEmail = u.email;
          }
        });

        if (existsOther) {
          setRoleToggleError(`สิทธิ์ "อาจารย์ผู้สอน" ในระบบจำกัดให้มีเพียงท่านเดียวเท่านั้น! ขณะนี้สิทธิ์นั้นถูกใช้งานโดยคุณครู: "${otherName}" (${otherEmail}) เพื่อความเป็นระเบียบ โปรดยกเลิกสิทธิ์อื่นก่อนกดเริ่มใหม่`);
          return;
        }
      } catch (err) {
        console.error("Failed to verify instructor limit: ", err);
      }
    }

    try {
      const userRef = doc(db, 'users', currentUser.uid);
      await updateDoc(userRef, { role: nextRole });
      setCurrentUser(prev => prev ? { ...prev, role: nextRole } : null);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${currentUser.uid}`);
    }
  };

  // Student name update logic
  const handleUpdateName = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!newName.trim() || !currentUser) return;
    setIsUpdatingName(true);
    setRoleToggleError(null);
    try {
      const userRef = doc(db, 'users', currentUser.uid);
      await updateDoc(userRef, { name: newName.trim() });
      setCurrentUser(prev => prev ? { ...prev, name: newName.trim() } : null);
      setIsEditingName(false);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${currentUser.uid}`);
    } finally {
      setIsUpdatingName(false);
    }
  };

  // Name update logic specifically inside the navigation drawer
  const handleUpdateNameInDrawer = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!drawerNewName.trim() || !currentUser) return;
    setIsUpdatingName(true);
    try {
      const userRef = doc(db, 'users', currentUser.uid);
      await updateDoc(userRef, { name: drawerNewName.trim() });
      setCurrentUser(prev => prev ? { ...prev, name: drawerNewName.trim() } : null);
      setIsEditingNameInDrawer(false);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${currentUser.uid}`);
    } finally {
      setIsUpdatingName(false);
    }
  };

  // Submit Course creation (Instructors only)
  const handleCreateCourse = async (title: string, description: string, bannerColor: string, enrollmentCode?: string) => {
    if (!currentUser) return;
    
    try {
      const courseId = `course_${Date.now()}`;
      const newCourseDoc: Course = {
        id: courseId,
        title,
        description,
        bannerColor,
        creatorId: currentUser.uid,
        creatorName: currentUser.name,
        creatorEmail: currentUser.email,
        enrollmentCode,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      await setDoc(doc(db, 'courses', courseId), newCourseDoc);
      setShowAddCourseModal(false);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'courses');
    }
  };

  // Student enroll process
  const handleEnrollCourse = async (course: Course) => {
    if (!currentUser) return;
    
    let code = null;
    if (course.enrollmentCode) {
      code = prompt("คอร์สนี้ถูกล็อกด้วยรหัสผ่าน โปรดกรอกรหัสเข้าร่วม:");
      if (code !== course.enrollmentCode) {
        alert("รหัสไม่ถูกต้อง!");
        return;
      }
    }

    try {
      setEnrollingCourseId(course.id);
      
      await runTransaction(db, async (transaction) => {
        const courseRef = doc(db, 'courses', course.id);
        const courseDoc = await transaction.get(courseRef);
        
        if (!courseDoc.exists()) throw new Error("ไม่พบห้องเรียนนี้");
        
        const courseData = courseDoc.data() as Course;
        
        // Check if code was already used
        if (course.enrollmentCode && !courseData.enrollmentCode) {
          throw new Error("คอร์สนี้ถูกจองไปแล้วโดยผู้อื่นครับ");
        }
        
        // Re-check enrollment code in transaction to be safe
        if (course.enrollmentCode && code !== courseData.enrollmentCode) {
             throw new Error("รหัสไม่ถูกต้อง");
        }

        // Create enrollment document
        const enrollmentId = `${currentUser.uid}_${course.id}`;
        const enrollmentRef = doc(db, 'enrollments', enrollmentId);
        
        const newEnrollment: Enrollment = {
          id: enrollmentId,
          userId: currentUser.uid,
          courseId: course.id,
          userName: currentUser.name,
          userEmail: currentUser.email,
          enrolledAt: new Date().toISOString()
        };
        
        transaction.set(enrollmentRef, newEnrollment);
        
        // Clear the enrollment code to lock it
        if (course.enrollmentCode) {
          transaction.update(courseRef, { enrollmentCode: deleteField(), updatedAt: new Date().toISOString() });
        }
      });
        
    } catch (err: any) {
      alert(err.message || "เกิดข้อผิดพลาดในการลงทะเบียน");
      handleFirestoreError(err, OperationType.CREATE, 'enrollments');
    } finally {
      setEnrollingCourseId(null);
    }
  };

  // Check enrollment matching
  const checkIsEnrolled = (courseId: string) => {
    return userEnrollments.some((e) => e.courseId === courseId);
  };

  // Filter courses based on user selection & search
  const filteredCourses = courses.filter((course) => {
    const matchesSearch =
      course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.creatorName.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;

    if (activeFilter === 'enrolled') {
      return checkIsEnrolled(course.id);
    }
    if (activeFilter === 'my-created') {
      return course.creatorId === currentUser?.uid;
    }
    return true;
  });

  // Simple Google Auth Trigger for Gate page
  const handleLogin = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (error) {
      console.error("Google authentication failed", error);
    }
  };

  if (!hasAgreedToPolicy) {
    return (
      <PolicyPage 
        onAgree={() => {
          setHasAgreedToPolicy(true);
          localStorage.setItem('agreedToPolicy', 'true');
        }} 
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-r from-[#B8E5FC] via-white to-[#B8E5FC] flex flex-col font-sans text-slate-800" id="main-app-container">
      
      {/* Sliding Navigation Drawer (Google Classroom Style Sidebar) */}
      <AnimatePresence>
        {isDrawerOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.4 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsDrawerOpen(false)}
              className="fixed inset-0 bg-zinc-900/40 z-50 backdrop-blur-[2px]"
              id="drawer-backdrop"
            />
            
            {/* Drawer Container */}
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 220 }}
              className="fixed left-0 top-0 bottom-0 w-80 max-w-[85vw] bg-white z-55 shadow-2xl flex flex-col border-r border-zinc-200 text-left"
              id="navigation-drawer"
            >
              {/* Header */}
              <div className="p-4 border-b border-zinc-150 flex items-center justify-between bg-white">
                <div className="flex items-center space-x-2.5">
                  <img
                    src={mascotLogo}
                    alt="English By Pox Mascot"
                    referrerPolicy="no-referrer"
                    className="h-9 w-9 object-contain rounded-lg border border-slate-100"
                  />
                  <div className="text-left">
                    <span className="font-sans font-semibold text-sm text-zinc-800 block tracking-tight">
                      English By Pox
                    </span>
                    <span className="text-[10px] text-zinc-400 block -mt-0.5 font-medium leading-none">
                      แอพห้องเรียนออนไลน์สุดเก๋
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => setIsDrawerOpen(false)}
                  className="p-1.5 hover:bg-zinc-100 rounded-full text-zinc-500 transition-colors cursor-pointer"
                  title="ปิดเมนู"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              {/* User Profile Info section of the drawer */}
              {currentUser && (
                <div className="p-4 border-b border-zinc-105 border-zinc-200 bg-zinc-50/50 space-y-3">
                  <div className="flex items-center space-x-3">
                    <img
                      referrerPolicy="no-referrer"
                      src={currentUser.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=80&q=80'}
                      alt={currentUser.name}
                      className="h-10 w-10 rounded-full border border-zinc-200 object-cover"
                    />
                    <div className="flex-grow overflow-hidden text-left">
                      {isEditingNameInDrawer ? (
                        <form
                          onSubmit={(e) => {
                            e.preventDefault();
                            handleUpdateNameInDrawer();
                          }}
                          className="flex items-center space-x-1.5"
                        >
                          <input
                            type="text"
                            value={drawerNewName}
                            onChange={(e) => setDrawerNewName(e.target.value)}
                            className="bg-white border border-gray-300 focus:border-blue-500 rounded px-2 py-1 text-xs text-zinc-800 outline-none w-full max-w-[120px]"
                            maxLength={50}
                            required
                            autoFocus
                          />
                          <button
                            type="submit"
                            title="บันทึก"
                            className="p-1 bg-blue-600 text-white rounded hover:bg-blue-700 cursor-pointer text-[10px]"
                          >
                            <Check className="h-3 w-3" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setIsEditingNameInDrawer(false)}
                            title="ยกเลิก"
                            className="p-1 bg-zinc-200 text-zinc-650 rounded hover:bg-zinc-300 cursor-pointer text-[10px]"
                          >
                            <X className="h-3 w-3" />
                          </button>
                        </form>
                      ) : (
                        <div className="flex items-center space-x-1.5">
                          <p className="text-xs font-bold text-zinc-800 truncate max-w-[110px]">
                            {currentUser.name}
                          </p>
                          <button
                            onClick={() => {
                              setIsEditingNameInDrawer(true);
                              setDrawerNewName(currentUser.name);
                            }}
                            className="p-0.5 text-zinc-400 hover:text-blue-600 rounded cursor-pointer"
                            title="แก้ไขชื่อโปรไฟล์"
                          >
                            <Pencil className="h-2.5 w-2.5" />
                          </button>
                        </div>
                      )}
                      <p className="text-[10px] text-zinc-400 truncate mt-0.5">{currentUser.email}</p>
                    </div>
                  </div>

                  {/* Mobile Role indicator/trigger inside Drawer */}
                  <div className="flex items-center justify-between bg-white border border-zinc-250 border-zinc-200 p-2 rounded-lg">
                    <span className="text-[10px] text-zinc-500 font-sans font-medium">
                      สถานะ: <span className="text-blue-600 font-bold">{currentUser.role === 'instructor' ? 'ผู้สอน' : 'นักเรียน'}</span>
                    </span>
                    <button
                      onClick={() => {
                        handleRoleToggle();
                      }}
                      className="flex items-center space-x-1 bg-blue-50 hover:bg-blue-100 text-blue-600 px-2 py-1 rounded text-[10px] font-bold border border-blue-150 transition-all cursor-pointer"
                    >
                      <RefreshCw className="h-2.5 w-2.5" />
                      <span>สลับสิทธิ์</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Navigation Items / Custom Tab Bar links in side drawer */}
              <div className="flex-1 overflow-y-auto p-2 space-y-1">
                <span className="text-[10px] uppercase font-bold text-zinc-400 tracking-wider px-3 py-2 block">
                  หน้าหลักและตัวกรอง
                </span>
                
                <button
                  onClick={() => {
                    setActiveCourse(null);
                    setActiveFilter('all');
                    setIsDrawerOpen(false);
                  }}
                  className={`w-full flex items-center space-x-3 px-3 py-2.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${activeFilter === 'all' && !activeCourse ? 'bg-blue-50 text-blue-600 border border-blue-100' : 'text-zinc-600 hover:bg-zinc-50'}`}
                >
                  <BookOpen className="h-4 w-4" />
                  <span>วิชาเรียนทั้งหมด ({courses.length})</span>
                </button>

                <button
                  onClick={() => {
                    setActiveCourse(null);
                    setActiveFilter('enrolled');
                    setIsDrawerOpen(false);
                  }}
                  className={`w-full flex items-center space-x-3 px-3 py-2.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${activeFilter === 'enrolled' && !activeCourse ? 'bg-blue-50 text-blue-600 border border-blue-100' : 'text-zinc-600 hover:bg-zinc-50'}`}
                >
                  <Users className="h-4 w-4" />
                  <span>ฉันลงเรียนไว้ ({userEnrollments.length})</span>
                </button>

                {currentUser && currentUser.role === 'instructor' && (
                  <button
                    onClick={() => {
                      setActiveCourse(null);
                      setActiveFilter('my-created');
                      setIsDrawerOpen(false);
                    }}
                    className={`w-full flex items-center space-x-3 px-3 py-2.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${activeFilter === 'my-created' && !activeCourse ? 'bg-blue-50 text-blue-600 border border-blue-100' : 'text-zinc-600 hover:bg-zinc-50'}`}
                  >
                    <GraduationCap className="h-4 w-4" />
                    <span>คอร์สที่ฉันสร้าง</span>
                  </button>
                )}

                {activeCourse && (
                  <>
                    <div className="h-px bg-zinc-200 my-2" />
                    <span className="text-[10px] uppercase font-bold text-zinc-400 tracking-wider px-3 py-2 block">
                      คอร์สกำลังเปิดอยู่
                    </span>
                    <div className="px-3 py-2 text-xs font-medium text-zinc-700 bg-yellow-50/50 rounded-lg border border-yellow-105 border-yellow-100 line-clamp-2">
                       {activeCourse.title}
                    </div>
                  </>
                )}
              </div>

              {/* Drawer Footer info strip */}
              <div className="p-4 border-t border-zinc-100 text-[10px] text-zinc-400 text-center font-sans">
                 English By Pox Classroom
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Navbar layer */}
      <Navbar
        user={currentUser}
        onRoleToggle={handleRoleToggle}
        isLoading={isLoadingAuth}
        onHome={() => setActiveCourse(null)}
        onMenuClick={() => setIsDrawerOpen(prev => !prev)}
        unreadNotificationsCount={notifications.filter(n => !n.isRead).length}
        onNotificationsClick={() => setIsNotificationsOpen(true)}
        onDMClick={() => setIsDMOpen(true)}
      />

      {/* Main Screen Layout logic */}
      <main className="flex-grow flex flex-col">
        {isLoadingAuth ? (
          /* Loading center spinner */
          <div className="flex-grow flex flex-col items-center justify-center p-8 space-y-3">
            <div className="h-10 w-10 border-4 border-sky-400 border-t-transparent rounded-full animate-spin"></div>
            <p className="text-sm font-semibold text-slate-500 font-sans">กำลังเปิดประตูเข้าสู่ระบบ...</p>
          </div>
        ) : !currentUser ? (
          /* Not Authenticated - GORGEOUS THAI ACCESS GATE with Shiba Mascot */
          <div className="flex-grow flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-[#B8E5FC] via-white to-[#B8E5FC]">
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="max-w-2xl w-full text-center space-y-8 bg-gradient-to-r from-[#F6EFCD] via-white to-[#F6EFCD] p-8 sm:p-12 rounded-xl border border-gray-200 shadow-sm"
              id="auth-gate-panel"
            >
              {/* Animated Mascot Container */}
              <div className="relative mx-auto h-28 w-28 flex items-center justify-center">
                <motion.img 
                  src={mascotLogo} 
                  alt="BlueClass Mascot" 
                  referrerPolicy="no-referrer"
                  className="h-24 w-24 object-contain rounded-2xl border border-slate-100 shadow-sm bg-white"
                  animate={{ y: [0, -4, 0] }}
                  transition={{ repeat: Infinity, duration: 3, ease: "easeInOut" }}
                />
                <div className="absolute -bottom-1 -right-1 bg-yellow-400 text-slate-900 rounded-full p-1.5 border border-white shadow-xs">
                  <Sparkles className="h-3.5 w-3.5 fill-slate-900 text-slate-900" />
                </div>
              </div>

              <div className="space-y-2">
                <h1 className="text-2xl sm:text-3xl font-sans font-medium text-zinc-800 tracking-tight">
                  ระบบห้องเรียน English By Pox
                </h1>
                <p className="text-xs sm:text-sm text-zinc-500 max-w-lg mx-auto font-sans leading-relaxed">
                  ยินดีต้อนรับสู่ <span className="text-blue-600 font-semibold font-sans">English By Pox</span> แอพห้องเรียนออนไลน์ที่มีสุนัขชิบะสุดน่ารักคอยดูแลความสนุกในการเรียนรู้วันนี้ร่วมกัน!
                </p>
              </div>

              {/* Grid of features in Thai */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 max-w-xl mx-auto">
                <div className="p-4 bg-white/80 rounded-xl border border-[#B8E5FC]/50 text-left space-y-1.5 shadow-sm">
                  <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-[#B8E5FC] to-blue-50 flex items-center justify-center text-black mb-2 border border-[#B8E5FC]/60 shadow-xs">
                    <ShieldCheck className="h-4.5 w-4.5" strokeWidth={1.5} />
                  </div>
                  <h4 className="text-xs font-bold text-zinc-800">ลงชื่อเข้าใช้ง่าย</h4>
                  <p className="text-[10px] text-zinc-600 leading-relaxed font-sans">สวมบทบาทเป็นครูหรือเรียนได้ทันทีด้วยบัญชี Google Account</p>
                </div>

                <div className="p-4 bg-white/80 rounded-xl border border-[#B8E5FC]/50 text-left space-y-1.5 shadow-sm">
                  <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-[#B8E5FC] to-blue-50 flex items-center justify-center text-black mb-2 border border-[#B8E5FC]/60 shadow-xs">
                    <Video className="h-4.5 w-4.5" strokeWidth={1.5} />
                  </div>
                  <h4 className="text-xs font-bold text-zinc-800">สื่อการสอนมีระเบียบ</h4>
                  <p className="text-[10px] text-zinc-600 leading-relaxed font-sans">เข้าชมสื่อคลิปวิดีโอ YouTube เอกสารประกอบการเรียนที่จัดวางตามหัวข้อ</p>
                </div>

                <div className="p-4 bg-white/80 rounded-xl border border-[#B8E5FC]/50 text-left space-y-1.5 shadow-sm">
                  <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-[#B8E5FC] to-blue-50 flex items-center justify-center text-black mb-2 border border-[#B8E5FC]/60 shadow-xs">
                    <Users className="h-4.5 w-4.5" strokeWidth={1.5} />
                  </div>
                  <h4 className="text-xs font-bold text-zinc-800">อภิปรายใต้บทเรียน</h4>
                  <p className="text-[10px] text-zinc-600 leading-relaxed font-sans">พูดคุย สอบถาม แลกเปลี่ยนข้อสงสัยกับผู้สอนและเพื่อนๆ ในคอร์ส</p>
                </div>
              </div>

              <div className="pt-4">
                <button
                  onClick={handleLogin}
                  className="inline-flex items-center space-x-3 bg-white border border-gray-200 hover:bg-gray-50 text-gray-700 font-semibold px-8 py-3 rounded-lg text-xs sm:text-sm shadow-sm transition-colors cursor-pointer"
                  id="btn-gate-signin"
                >
                  <svg className="h-4.5 w-4.5" viewBox="0 0 48 48">
                    <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>
                    <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>
                    <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/>
                    <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/>
                    <path fill="none" d="M0 0h48v48H0z"/>
                  </svg>
                  <span>เข้าสู่ห้องเรียนด้วยบัญชี Google</span>
                </button>
              </div>

              <div className="pt-2 text-[10px] text-zinc-400 font-sans flex items-center justify-center space-x-1">
                <Info className="h-3.5 w-3.5" />
                <button
            onClick={() => {
              setHasAgreedToPolicy(false);
              localStorage.removeItem('agreedToPolicy');
            }}
            className="text-[10px] text-zinc-400 cursor-pointer underline hover:text-zinc-600 font-sans"
          >
            โดยการเข้าชั้นเรียน คุณตกลงที่จะใช้ข้อมูลร่วมกับห้องเรียน English By Pox
          </button>
              </div>
            </motion.div>
          </div>
        ) : activeCourse ? (
          /* ACTIVE CLASSROOM INTERACTIVE DASHBOARD VIEW */
          <CourseDetail
            course={activeCourse}
            currentUser={currentUser}
            onBack={() => {
              setActiveCourse(null);
            }}
          />
        ) : (
          /* CORE CLASS LISTING DIRECTORY */
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-grow flex flex-col space-y-6">
            
            {/* Top Stats Welcome Strip in Google Format */}
            <div className="bg-gradient-to-r from-[#F6EFCD] via-white to-[#F6EFCD] border border-gray-200 rounded-xl p-6 text-left flex flex-col md:flex-row justify-between items-center gap-6 shadow-3xs relative overflow-hidden">
              <div className="absolute top-0 right-0 p-8 opacity-5 bg-blue-600 w-48 h-48 rounded-full pointer-events-none"></div>
              
              <div className="space-y-2 z-10 md:w-3/4">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-[10px] bg-blue-50 text-blue-700 px-2.5 py-0.5 rounded font-bold">สวัสดีครับ</span>
                  <span className="text-[10px] bg-zinc-100 text-zinc-600 px-2.5 py-0.5 rounded font-mono">
                    บทบาท: {currentUser.role === 'instructor' ? 'อาจารย์ผู้สอน' : 'นักเรียน'}
                  </span>
                </div>

                {isEditingName ? (
                  <form onSubmit={handleUpdateName} className="flex items-center space-x-2 pt-1">
                    <input
                      type="text"
                      value={newName}
                      onChange={(e) => setNewName(e.target.value)}
                      className="bg-zinc-50 border border-gray-300 focus:border-blue-500 focus:bg-white rounded-lg px-3 py-1.5 text-xs sm:text-sm text-zinc-800 outline-none transition-all placeholder:text-zinc-400 font-sans font-medium w-full max-w-xs"
                      placeholder="พิมพ์ชื่อใหม่ของคุณ..."
                      maxLength={50}
                      required
                      autoFocus
                    />
                    <button
                      type="submit"
                      disabled={isUpdatingName}
                      className="p-2 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white rounded-lg transition-colors cursor-pointer"
                      title="บันทึกชื่อ"
                    >
                      {isUpdatingName ? (
                        <div className="h-4.5 w-4.5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      ) : (
                        <Check className="h-4.5 w-4.5" />
                      )}
                    </button>
                    <button
                      type="button"
                      onClick={() => setIsEditingName(false)}
                      className="p-2 bg-zinc-100 hover:bg-zinc-200 text-zinc-650 rounded-lg transition-colors cursor-pointer"
                      title="ยกเลิก"
                    >
                      <X className="h-4.5 w-4.5" />
                    </button>
                  </form>
                ) : (
                  <div className="flex items-center space-x-2">
                    <h2 className="font-sans font-medium text-lg sm:text-xl text-zinc-800">
                      ยินดีต้อนรับเข้าสู่ระบบ English By Pox, {currentUser.name}!
                    </h2>
                    {currentUser && (
                      <button
                        onClick={() => {
                          setIsEditingName(true);
                          setNewName(currentUser.name);
                        }}
                        className="p-1 text-zinc-400 hover:text-blue-600 hover:bg-blue-50 rounded transition-all cursor-pointer"
                        title="แก้ไขชื่อผู้แสดงผล"
                        id="btn-edit-user-name"
                      >
                        <Pencil className="h-3.5 w-3.5" />
                      </button>
                    )}
                  </div>
                )}

                <p className="text-xs text-zinc-500 max-w-2xl leading-normal">
                  {currentUser.role === 'instructor' 
                    ? 'คุณครูสามารถสร้างห้องรายวิชาเรียนใหม่ อัปเดตสื่อบอร์ดการเขียน แทรกสไลด์ และวิดีโอบรรยาย เพื่อเผยแพร่แก่นักเรียนเรียนรู้ฟรีทางด้านล่างได้ทันทีเลยครับ' 
                    : 'ค้นหารายวิชาเรียนที่คุณสนใจทางด้านล่าง เพื่อร่วมลงทะเบียนเข้าเรียนฟรี สะสมคะแนน อัปโหลดเอกสาร ร่วมถามตอบกับครูผู้ฝึกสอนได้สะดวกสบาย'}
                </p>
              </div>

              {/* Shiba Mascot Interactive Greeting on the welcome banner */}
              <div className="flex flex-col items-center justify-center shrink-0 w-full md:w-auto z-10 border-t md:border-t-0 pt-4 md:pt-0 md:pl-6 border-zinc-100">
                <div className="flex items-center space-x-3">
                  <img
                    src={mascotLogo}
                    alt="Mascot Shiba"
                    referrerPolicy="no-referrer"
                    className="h-14 w-14 object-contain animate-bounce bg-white p-1 rounded-xl border border-gray-200 shadow-3xs"
                  />
                  {currentUser.role === 'instructor' ? (
                    <button
                      onClick={() => setShowAddCourseModal(true)}
                      className="flex items-center space-x-1 bg-blue-650 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2.5 rounded-lg text-xs font-semibold shadow-xs transition-colors cursor-pointer"
                      id="btn-add-course-show"
                    >
                      <Plus className="h-4 w-4" />
                      <span>สร้างวิชาเรียน</span>
                    </button>
                  ) : (
                    <div className="text-left">
                      <span className="text-[9px] text-zinc-400 block font-bold uppercase">วิชาที่ฉันเข้าร่วม</span>
                      <span className="text-xs font-bold text-zinc-700 block bg-blue-50/80 px-2 py-0.5 rounded border border-blue-100 mt-0.5">{userEnrollments.length} คอร์สเรียน</span>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Role switch duplicate teacher error banner */}
            {roleToggleError && (
              <div className="bg-red-50 border-l-4 border-red-500 p-4 rounded-r-lg flex items-start justify-between shadow-xs animate-pulse">
                <div className="flex items-start space-x-3 text-red-800">
                  <AlertTriangle className="h-5 w-5 shrink-0 text-red-500 mt-0.5" />
                  <div className="text-left text-xs sm:text-sm font-sans leading-relaxed">
                    <span className="font-bold">ตรวจสอบการเปลี่ยนสิทธิ์:</span> {roleToggleError}
                  </div>
                </div>
                <button 
                  onClick={() => setRoleToggleError(null)} 
                  className="p-1 hover:bg-red-100 rounded text-red-500 transition-colors cursor-pointer"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            )}

            {/* Filter Hub Toolbar */}
            <div className="flex flex-col md:flex-row gap-4 justify-between items-center bg-gradient-to-r from-[#F6EFCD] via-white to-[#F6EFCD] p-4 rounded-xl border border-gray-200 shadow-3xs">
              
              {/* Left filter buttons */}
              <div className="flex items-center space-x-1 bg-zinc-100 p-1 rounded-lg self-start md:self-center">
                <button
                  onClick={() => setActiveFilter('all')}
                  className={`flex items-center space-x-1 px-3 py-1.5 rounded-md text-xs font-semibold transition-all cursor-pointer ${activeFilter === 'all' ? 'bg-white text-zinc-800 shadow-3xs' : 'text-zinc-500 hover:text-zinc-700'}`}
                >
                  <span>วิชาทั้งหมด ({courses.length})</span>
                </button>
                <button
                  onClick={() => setActiveFilter('enrolled')}
                  className={`flex items-center space-x-1 px-3 py-1.5 rounded-md text-xs font-semibold transition-all cursor-pointer ${activeFilter === 'enrolled' ? 'bg-white text-zinc-800 shadow-3xs' : 'text-zinc-500 hover:text-zinc-700'}`}
                >
                  <span>ฉันลงเรียนไว้ ({userEnrollments.length})</span>
                </button>
                {currentUser.role === 'instructor' && (
                  <button
                    onClick={() => setActiveFilter('my-created')}
                    className={`flex items-center space-x-1 px-3 py-1.5 rounded-md text-xs font-semibold transition-all cursor-pointer ${activeFilter === 'my-created' ? 'bg-white text-zinc-800 shadow-3xs' : 'text-zinc-500 hover:text-zinc-700'}`}
                  >
                    <span>คอร์สที่ฉันสร้าง</span>
                  </button>
                )}
              </div>

              {/* Right Search Bar */}
              <div className="relative w-full md:w-80">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-zinc-400">
                  <Search className="h-4 w-4" />
                </div>
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="ค้นหา วิชาเรียน, ชื่ออาจารย์ผู้สอน..."
                  className="w-full bg-zinc-50 focus:bg-white border border-gray-200 focus:border-blue-500 rounded-lg pl-9 pr-4 py-2 text-xs outline-none transition-all placeholder:text-zinc-400"
                />
              </div>

            </div>

            {/* Courses Matrix Grid */}
            {isLoadingData ? (
              <div className="py-24 text-center text-zinc-400 space-y-2">
                <div className="h-8 w-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
                <p className="text-xs font-sans">กำลังอัปเดตระบบรายวิชาเรียนล่าสุด...</p>
              </div>
            ) : filteredCourses.length === 0 ? (
              /* No matching search/filters placeholder */
              <div className="bg-white rounded-xl p-16 text-center border-2 border-dashed border-zinc-200 space-y-3">
                <BookOpen className="h-12 w-12 text-zinc-300 mx-auto" />
                <h3 className="font-sans font-medium text-zinc-700 text-sm">ไม่พบคอร์สเรียนที่กรอง</h3>
                <p className="text-zinc-400 text-xs max-w-sm mx-auto font-sans leading-relaxed">
                  ไม่พบคอร์สเรียนที่สอดคล้องกับตัวค้นหาของคุณ ลองล้างตัวกรองหรือเปลี่ยนคำค้นภาษาไทยใหม่อีกครั้งนะครับ
                </p>
                <button
                  onClick={() => { setSearchQuery(''); setActiveFilter('all'); }}
                  className="text-xs font-semibold text-blue-600 hover:underline cursor-pointer"
                >
                  ล้างตัวกรองทั้งหมด
                </button>
              </div>
            ) : (
              /* Display matching cards */
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredCourses.map((course) => (
                  <div key={course.id}>
                    <CourseCard
                      course={course}
                      isEnrolled={checkIsEnrolled(course.id)}
                      isCreator={course.creatorId === currentUser.uid}
                      onView={() => setActiveCourse(course)}
                      onEnroll={() => handleEnrollCourse(course)}
                      isProcessing={enrollingCourseId === course.id}
                    />
                  </div>
                ))}
              </div>
            )}

          </div>
        )}
      </main>

      {/* Course Creaton Dynamic Sheet */}
      {showAddCourseModal && (
        <CourseForm
          onSubmit={handleCreateCourse}
          onClose={() => setShowAddCourseModal(false)}
        />
      )}

      {/* Footer Info Statement */}
      <footer className="bg-white border-t border-gray-250 border-gray-200 py-6 text-center">
        <p className="text-[10px] text-zinc-400 font-sans">
          © {new Date().getFullYear()} English By Pox — คลับแบ่งปันสื่อการสอนและชีตความรู้ฟรีผ่านระบบคลาวด์
        </p>
      </footer>

      {/* Notifications Modal */}
      {isNotificationsOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={() => setIsNotificationsOpen(false)}>
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-sm max-h-[80vh] overflow-y-auto p-5" onClick={(e) => e.stopPropagation()}>
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-sm text-zinc-800">การแจ้งเตือน</h3>
              <button onClick={() => setIsNotificationsOpen(false)} className="text-zinc-400 hover:text-zinc-600">×</button>
            </div>
            <div className="space-y-3">
              {notifications.map(n => (
                <div key={n.id} className={`p-3 rounded-lg border text-xs ${n.isRead ? 'bg-zinc-50 border-zinc-100' : 'bg-blue-50 border-blue-100'} cursor-pointer`} onClick={async () => {
                  if (!n.isRead) await updateDoc(doc(db, 'notifications', n.id), { isRead: true });
                }}>
                  <div className="font-bold text-zinc-900">{n.title}</div>
                  <div className="text-zinc-600 mt-1">{n.content}</div>
                </div>
              ))}
              {notifications.length === 0 && <p className="text-xs text-center text-zinc-400 py-4">ยังไม่มีการแจ้งเตือน</p>}
            </div>
          </div>
        </div>
      )}

      {/* DM Modal */}
      {isDMOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={() => setIsDMOpen(false)}>
          <div className="bg-zinc-50 rounded-2xl shadow-2xl w-full max-w-md h-[80vh] flex flex-col overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center p-3 border-b border-zinc-200 shrink-0 bg-gradient-to-r from-[#F6EFCD] via-white to-[#F6EFCD]">
              <button onClick={() => { if(dmRecipientId) setDmRecipientId(null); else setIsDMOpen(false); }} className="text-zinc-500 hover:text-zinc-800 p-2">
                ←
              </button>
              {dmRecipientId && (
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-zinc-200 overflow-hidden">
                    <img src={(allStudents.find(s => s.uid === dmRecipientId)?.photoURL || allInstructors.find(i => i.uid === dmRecipientId)?.photoURL) || '/default-avatar.png'} alt={dmRecipientName} className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-sm text-zinc-900">{dmRecipientName}</h3>
                    <p className={`text-[10px] ${((allStudents.find(s => s.uid === dmRecipientId) || allInstructors.find(i => i.uid === dmRecipientId))?.status === 'online') ? 'text-green-500' : 'text-zinc-400'}`}>
                      {((allStudents.find(s => s.uid === dmRecipientId) || allInstructors.find(i => i.uid === dmRecipientId))?.status === 'online') ? 'online' : 'offline'}
                    </p>
                  </div>
                </div>
              )}
              {!dmRecipientId && <h3 className="font-bold text-sm text-zinc-800 flex-grow text-center">Messages</h3>}
            </div>
            
            {!dmRecipientId ? (
              <div className="flex-grow overflow-y-auto min-h-0 p-2 bg-white">
                {currentUser?.role === 'instructor' ? (
                  <>
                    {allStudents.map(stu => (
                      <button key={stu.uid} onClick={() => { setDmRecipientId(stu.uid); setDmRecipientName(stu.name); }} className="w-full text-left p-3 rounded-xl hover:bg-zinc-200/50 transition-colors flex items-center gap-4">
                        <div className="relative">
                          <img src={stu.photoURL} alt={stu.name} className="w-12 h-12 rounded-full border border-zinc-200" />
                           <div className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-white ${stu.status === 'online' ? 'bg-green-500' : 'bg-zinc-400'}`} />
                        </div>
                        <div className="flex-grow">
                          <div className="flex justify-between">
                            <span className="text-sm font-semibold text-zinc-900">{stu.name}</span>
                          </div>
                          <p className="text-xs text-zinc-500 truncate">{stu.status === 'online' ? 'Online' : 'Offline'}</p>
                        </div>
                      </button>
                    ))}
                  </>
                ) : (
                  <>
                    <h4 className="text-xs font-semibold text-zinc-500 mb-3 px-3">Instructors</h4>
                    {allInstructors.map(inst => (
                      <button key={inst.uid} onClick={() => { setDmRecipientId(inst.uid); setDmRecipientName(inst.name); }} className="w-full text-left p-3 rounded-xl hover:bg-zinc-200/50 transition-colors flex items-center gap-4">
                        <div className="relative">
                            <img src={inst.photoURL} alt={inst.name} className="w-12 h-12 rounded-full border border-zinc-200" />
                             <div className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-white ${inst.status === 'online' ? 'bg-green-500' : 'bg-zinc-400'}`} />
                        </div>
                        <div className="flex-grow">
                          <div className="flex justify-between">
                            <span className="text-sm font-semibold text-zinc-900">{inst.name}</span>
                          </div>
                          <p className="text-xs text-zinc-500 truncate">{inst.status === 'online' ? 'Online' : 'Offline'}</p>
                        </div>
                      </button>
                    ))}
                  </>
                )}
              </div>
            ) : (
              <div className="flex-grow flex flex-col bg-white min-h-0">
                <>
                  <div className="flex-grow overflow-y-auto min-h-0 p-4 space-y-3">
                    {(() => {
                      const filteredMessages = dmMessages
                        .filter(m => m.roomId === [currentUser!.uid, dmRecipientId].sort().join('_'))
                        .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
                      
                      if (filteredMessages.length === 0) {
                        return (
                          <div className="h-full flex flex-col justify-center items-center text-center p-6 bg-zinc-50 rounded-xl border border-zinc-200 border-dashed m-4">
                            <div className="bg-amber-50 rounded-full p-2.5 mb-3 border border-amber-200">
                              <AlertTriangle className="w-5 h-5 text-amber-500" />
                            </div>
                            <p className="text-xs font-bold text-zinc-700 uppercase tracking-widest mb-1.5">System Notice / ประกาศจากระบบ</p>
                            <p className="text-xs font-semibold text-red-600 mb-1 max-w-xs">
                              Strict Child Protection Filter Engaged
                            </p>
                            <p className="text-xs font-medium text-zinc-500 leading-relaxed max-w-xs mb-3">
                              The platform automatically moderates chat messages. Any sexual solicitation, explicit content, grooming, age exploitation, or safety-threatening inquiries are strictly blocked.
                            </p>
                            <div className="bg-white px-4 py-2.5 rounded-lg border border-zinc-200 shadow-sm inline-flex items-center gap-2">
                              <ShieldCheck className="w-4 h-4 text-emerald-500" />
                              <span className="text-[10px] font-semibold text-zinc-600">
                                Child Safety Standards Monitoring Active
                              </span>
                            </div>
                            <p className="text-[10px] font-medium text-zinc-400 mt-4 max-w-xs italic border-t border-zinc-200/60 pt-2.5 w-full">
                              The platform will not be responsible for any damages done.
                            </p>
                          </div>
                        );
                      }

                        return filteredMessages.map(m => {
                          if (m.isDeleted) {
                            return (
                              <div key={m.id} className="flex justify-center my-1.5">
                                <div className="bg-zinc-100 text-zinc-400 font-medium text-[11px] px-3 py-1 rounded-full border border-zinc-200">
                                  {m.senderName || 'user'} unsend at {new Date(m.updatedAt || m.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                </div>
                              </div>
                            );
                          }

                          const isMine = m.senderId === currentUser!.uid;
                          const isHeld = heldMessageId === m.id;
                          return (
                            <div key={m.id} className={`flex ${isMine ? 'justify-end' : 'justify-start'} group`}>
                              <div 
                                onTouchStart={() => isMine && handleHoldStart(m.id)}
                                onTouchEnd={isMine ? handleHoldEnd : undefined}
                                onTouchMove={isMine ? handleHoldEnd : undefined}
                                onMouseDown={() => isMine && handleHoldStart(m.id)}
                                onMouseUp={isMine ? handleHoldEnd : undefined}
                                onMouseLeave={isMine ? handleHoldEnd : undefined}
                                onContextMenu={(e) => { if (isMine) e.preventDefault(); }}
                                className={`relative text-sm px-4 py-2 rounded-2xl max-w-[85%] shadow-sm ${isMine ? 'bg-gradient-to-r from-[#D4EBF9] via-white to-[#D4EBF9] text-zinc-900 rounded-br-none' : 'bg-white text-zinc-900 rounded-bl-none'} select-none`}
                              >
                                {m.isEdited && <div className="text-[9px] -mt-1 mb-1 italic text-zinc-500">Edited</div>}
                                {m.content}
                                <div className={`text-[9px] mt-1 flex justify-end items-center gap-1 ${isMine ? 'text-zinc-600' : 'text-zinc-400'}`}>
                                  {new Date(m.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                  {isMine && (
                                      <span className={m.isRead ? 'text-blue-800' : 'text-zinc-400'}>
                                        ✓{m.isRead ? '✓' : ''}
                                      </span>
                                  )}
                                </div>
                            
                                {isMine && (
                                  <div className={`absolute -left-8 top-1/2 -translate-y-1/2 flex items-center gap-1 transition-opacity ${activeMessageId === m.id || isHeld ? 'opacity-100' : 'opacity-0 md:group-hover:opacity-100'}`}>
                                    {activeMessageId === m.id ? (
                                      <>
                                        <button onClick={() => {
                                            setEditingMessageId(m.id);
                                            setDmText(m.content);
                                            setActiveMessageId(null);
                                            setHeldMessageId(null);
                                        }} className="p-1 text-zinc-600 bg-white rounded-full shadow-sm hover:text-blue-600">
                                            <Edit2 className="w-3 h-3" />
                                        </button>
                                        <button onClick={async () => {
                                            try {
                                              await updateDoc(doc(db, 'dm_messages', m.id), { 
                                                isDeleted: true,
                                                updatedAt: new Date().toISOString()
                                              });
                                              setActiveMessageId(null);
                                              setHeldMessageId(null);
                                            } catch (err) {
                                              handleFirestoreError(err, OperationType.UPDATE, `dm_messages/${m.id}`);
                                            }
                                        }} className="p-1 text-red-500 bg-white rounded-full shadow-sm hover:text-red-700">
                                            <Trash2 className="w-3 h-3" />
                                        </button>
                                      </>
                                    ) : (
                                      <button onClick={() => { setActiveMessageId(m.id); setHeldMessageId(null); }} className="p-1 text-zinc-400 hover:text-zinc-600">
                                          <MoreHorizontal className="w-3 h-3" />
                                      </button>
                                    )}
                                  </div>
                                )}
                              </div>
                            </div>
                          );
                        });
                      })()}
                    </div>
                    <div className="p-3 bg-white flex items-center gap-2 shrink-0">
                      <input type="text" value={dmText} onChange={(e) => setDmText(e.target.value)} className="flex-grow text-sm px-4 py-2.5 bg-zinc-100 rounded-full outline-none focus:bg-zinc-200" placeholder={editingMessageId ? "Edit message..." : "Message..."} />
                      {editingMessageId && (
                        <button onClick={() => {
                          setEditingMessageId(null);
                          setDmText('');
                        }} className="text-zinc-500 hover:text-zinc-700 text-xs px-2.5 py-1.5 hover:bg-zinc-100 rounded-full font-medium transition-colors shrink-0">
                          Cancel
                        </button>
                      )}
                      <button onClick={async () => {
                        if(!dmText.trim()) return;
                        
                        const check = checkSafety(dmText.trim());
                        if (!check.isSafe) {
                          alert(check.reason);
                          return;
                        }

                        if (editingMessageId) {
                          try {
                            await updateDoc(doc(db, 'dm_messages', editingMessageId), {
                              content: dmText.trim(),
                              isEdited: true,
                              updatedAt: new Date().toISOString()
                            });
                            setEditingMessageId(null);
                            setDmText('');
                          } catch (err) {
                            handleFirestoreError(err, OperationType.UPDATE, `dm_messages/${editingMessageId}`);
                          }
                          return;
                        }

                        const messageId = `dm_${Date.now()}`;
                        try {
                          await setDoc(doc(db, 'dm_messages', messageId), {
                            id: messageId,
                            roomId: [currentUser!.uid, dmRecipientId].sort().join('_'),
                            senderId: currentUser!.uid,
                            senderName: currentUser!.name,
                            recipientId: dmRecipientId,
                            recipientName: dmRecipientName,
                            content: dmText.trim(),
                            createdAt: new Date().toISOString(),
                            isRead: false,
                            isDeleted: false
                          });

                          // Create notification for recipient
                          await addDoc(collection(db, 'notifications'), {
                            id: `notif_${Date.now()}`,
                            recipientId: dmRecipientId,
                            senderId: currentUser!.uid,
                            title: 'ข้อความใหม่',
                            content: `${currentUser!.name} ได้ส่งข้อความถึงคุณ`,
                            isRead: false,
                            createdAt: new Date().toISOString()
                          });
                          setDmText('');
                        } catch (e) {
                          console.error("Error sending message:", e);
                          alert("Error sending message. Please try again.");
                        }
                      }} className="text-blue-600 font-semibold text-sm p-2 hover:bg-zinc-100 rounded-full">{editingMessageId ? 'Update' : 'Send'}</button>
                    </div>
                  </>
              </div>
            )}
          </div>
        </div>
      )}

    </div>
  );
}
