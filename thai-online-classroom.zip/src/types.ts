export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  photoURL: string;
  role: 'student' | 'instructor';
  createdAt?: string;
  status?: 'online' | 'offline'; // added status
  lastSeen?: string; // added lastSeen
}

export interface Course {
  id: string;
  title: string;
  description: string;
  bannerColor: string; // e.g. 'bg-blue-500'
  creatorId: string;
  creatorName: string;
  creatorEmail: string;
  enrollmentCode?: string; // Optional code for enrolling
  createdAt: any; // Firestore Timestamp or string
  updatedAt: any;
}

export interface Lesson {
  id: string;
  courseId: string;
  title: string;
  description: string;
  videoUrl: string; // URL of youtube or custom
  videoType: 'youtube' | 'vimeo' | 'direct' | 'other';
  order: number;
  createdAt: any;
}

export interface Material {
  id: string;
  courseId: string;
  lessonId?: string; // Optional linked lesson
  title: string;
  description: string;
  fileUrl: string; // Material hyperlink (Drive, Doc, pdf, web url)
  fileType: 'pdf' | 'doc' | 'link' | 'slide' | 'archive';
  uploadedBy: string;
  createdAt: any;
}

export interface Enrollment {
  id: string; // studentUid_courseId
  userId: string;
  courseId: string;
  userName: string;
  userEmail: string;
  enrolledAt: any;
}

export interface Comment {
  id: string;
  courseId: string;
  lessonId: string;
  userId: string;
  userName: string;
  userPhoto?: string;
  content: string;
  createdAt: any;
  parentId?: string; // Optional field linking a reply to its parent comment
}

export interface Notification {
  id: string;
  recipientId: string;
  senderId: string;
  senderName: string;
  senderPhotoURL?: string;
  title: string;
  content: string;
  courseId?: string;
  lessonId?: string;
  commentId?: string;
  dmRoomId?: string;
  isRead: boolean;
  createdAt: string;
}

export interface DMMessage {
  id: string;
  roomId: string; // Typically sorted comparison keys "user1_user2"
  senderId: string;
  senderName: string;
  senderPhotoURL?: string;
  recipientId: string;
  recipientName: string;
  content: string;
  createdAt: string;
  isRead: boolean; // added isRead
  isDeleted?: boolean; // added isDeleted
  isEdited?: boolean;
  updatedAt?: string;
}
