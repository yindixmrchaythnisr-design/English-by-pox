export const MODERATION_RULES = {
  boundary_testing_patterns: [
    {
      id: "R-GRM-001",
      description: "Student probing relation status / สอบถามสถานะความสัมพันธ์",
      pattern: /(are\s+you|do\s+you\s+have\s+a)\s+(single|dating|married|boyfriend|girlfriend|husband|wife|partner|husband|wife|แฟน|คนคุย|แต่งงาน|มีคู่|สามี|ภรรยา)/i
    },
    {
      id: "R-GRM-002",
      description: "Pivot to off-platform personal channels / เสนอไปคุยส่วนตัวภายนอกระบบ",
      pattern: /(text\s+me|add\s+my|send\s+me\s+pics?|hit\s+me\s+up|follow\s+me|แอด|ขอไลน์|ไอดี|เบอร์)\s*(on|ไลน์|line|snap|snapchat|insta|ig|discord|whatsapp|signal|telegram|imessage|phone|number|เบอร์โทร|fb|เฟส)/i
    },
    {
      id: "R-GRM-004",
      description: "Secretive/boundary-breaking phrases / พฤติกรรมปกปิดและสร้างข้อตกลงลับ",
      pattern: /(don't\s+tell|keep\s+this\s+between|our\s+little\s+secret|just\s+for\s+us|private\s+convo|ความลับ|อย่าบอกใคร|รู้กันแค่เรา|สองคน)/i
    },
    {
      id: "R-GRM-005",
      description: "Inappropriate comments on physical appearance / ความเห็นไม่เหมาะสมในเชิงชู้สาว",
      pattern: /(you\s+look|u\s+look|so)\s+(sexy|hot|fine|thicc|smash|baddie|เซ็กซี่|เอ็กซ์|หุ่นดี|น่าเอา)/i
    },
    {
      id: "R-GRM-006",
      description: "Prohibited probing of minor status or age / การสอบถามอายุหรือพฤติกรรมเสี่ยงต่อผู้เยาว์",
      pattern: /(how\s+old\s+are\s+you|whats?\s+your\s+age|are\s+you\s+a\s+minor|are\s+you\s+(under|below)\s+(18|sixteen|16)|how\s+old\s+u|what\s+age|u\s+age|อายุเท่าไหร่|อายุเท่าไร|อายุเท่าแร|อายุกี่ปี|อายุกี่ขวบ|อายุ|กี่ขวบ|กี่ปี|อายุเท่าเเล)/i
    },
    {
      id: "R-GRM-007",
      description: "Explicit sexually suggestive content / เนื้อหาทางเพศหรือชู้สาวที่โจ่งแจ้ง",
      pattern: /(send\s+nudes?|show\s+body|sexual|wanna\s+fuck|make\s+love|masturbat|cyber\s*sex|orgasm|naked|porn|เย็ด|ควย|หี|แตด|แตรด|เงี่ยน|เอากัน|สวิงกิ้ง|คอลเสียว|อมควย|ดูดควย|สอดใส่|จิ๋ม|รูปโป๊|ภาพโป๊|ขอดูรูปหลุด|ช่วยตัวเอง)/i
    }
  ],
  // Extra keywords to safeguard even with spacers, dots, etc.
  blocked_keywords: [
    // Age Probing Keywords
    "howold", "yourage", "whats_your_age", "whatsyourage", "howoldareu", "whats_ur_age", 
    "อายุเท่าไหร่", "อายุเท่าไร", "อายุกี่ปี", "อายุเท่าเเล", "กี่ขวบ", "กี่ปี", "อายุเท่าไร",
    // Explicit Sexual Keywords (EN)
    "wanna_fuck", "wannafuck", "masturbate", "vagina", "penis", "sexual", "nude", "naked", "porn", "anal",
    "f.u.c.k", "s.e.x", "n.u.d.e", "p.o.r.n", "fuck", 
    // Explicit Sexual Keywords (TH)
    "เย็ด", "ควย", "หวย", "แตด", "หี", "เจ็ดแม่", "เงี่ยน", "คอลเสียว", "อมควย", "ดูดควย", "ขอดูจิ๋ม",
    "ช่วยตัวเอง", "รูปโป๊", "ภาพโป๊", "เอาดุ", "นวดกษัย", "รับงาน", "เด็กเอ็น", "เด็กเอน", "เสียวจัง",
    "น้ำแตก", "แตกใน"
  ]
};

export function checkSafety(message: string): { isSafe: boolean; reason?: string } {
  const normalized = message.toLowerCase().replace(/[\s\.\-\_\,\*]+/g, "");

  // 1. Check Regex Patterns (Comprehensive checking)
  for (const rule of MODERATION_RULES.boundary_testing_patterns) {
    if (rule.pattern.test(message)) {
      return { 
        isSafe: false, 
        reason: `🔒 Child Protection & Safety Alert: This message was blocked as it matches restriction rules of "${rule.description}".` 
      };
    }
  }

  // 2. Exact keyword inclusion checks (preventing bypassed letters with spaces/characters)
  for (const kw of MODERATION_RULES.blocked_keywords) {
    if (normalized.includes(kw) || message.toLowerCase().includes(kw)) {
      return { 
        isSafe: false, 
        reason: "🔒 Child Protection & Safety Alert: This message was blocked because it contains restricted terminology regarding sexual content, minor protection, or physical exploitation." 
      };
    }
  }

  // 3. Specifically capture age probing separately via substring logic as extra backstop
  const numericWords = message.match(/\d+/g);
  const lowercaseMsg = message.toLowerCase();
  
  // English age probing variants
  if (
    lowercaseMsg.includes("how old") || 
    lowercaseMsg.includes("whats your age") || 
    lowercaseMsg.includes("what is your age") ||
    lowercaseMsg.includes("what's your age") ||
    lowercaseMsg.includes("tell me your age") ||
    (lowercaseMsg.includes("your age") && lowercaseMsg.includes("?")) ||
    (lowercaseMsg.includes("u") && lowercaseMsg.includes("age") && lowercaseMsg.includes("?")) ||
    (lowercaseMsg.includes("you") && lowercaseMsg.includes("age") && lowercaseMsg.includes("?"))
  ) {
    return {
      isSafe: false,
      reason: "🔒 Child Protection & Safety Alert: Asking for age or probing personal minor status is restricted on this educational platform."
    };
  }

  // Thai age probing variants
  if (
    lowercaseMsg.includes("อายุเท่าไหร่") ||
    lowercaseMsg.includes("อายุเท่าไร") ||
    lowercaseMsg.includes("อายุกี่ปี") ||
    lowercaseMsg.includes("อายุกี่ขวบ") ||
    (lowercaseMsg.includes("อายุ") && lowercaseMsg.includes("?")) ||
    (lowercaseMsg.includes("อายุ") && (lowercaseMsg.includes("กี่") || lowercaseMsg.includes("เท่า")))
  ) {
    return {
      isSafe: false,
      reason: "🔒 Child Protection & Safety Alert: การสอบถามอายุหรือพฤติกรรมสร้างพรมแดนละเมิดผู้เยาว์ถูกจำกัดในระบบอย่างเข้มงวด"
    };
  }

  return { isSafe: true };
}
